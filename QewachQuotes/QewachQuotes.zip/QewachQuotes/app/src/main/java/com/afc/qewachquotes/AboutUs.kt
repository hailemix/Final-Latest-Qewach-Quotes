package com.afc.qewachquotes

import android.os.Bundle
import android.support.v7.app.AppCompatActivity

class AboutUs : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.about_us)
    }
}