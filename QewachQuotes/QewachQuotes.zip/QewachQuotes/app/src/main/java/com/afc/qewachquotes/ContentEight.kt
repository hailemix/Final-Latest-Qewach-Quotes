package com.afc.qewachquotes

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import android.support.v4.content.ContextCompat
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.bumptech.glide.Glide


class ContentEight: FragmentActivity() {

    private lateinit var mAdView: AdView
    private lateinit  var mPager: ViewPager
    private lateinit var mPagerAdapter: PagerAdapter
    private var backgroundLayout: ImageView ?= null
    private lateinit var myButton : Button




    companion object {

        const val  KEY_CLICK_COUNT = "1"
        private val quoteContents = arrayOf(

                "ለማልቀስ ምቹዉ ስፍራ የእናት መዳፍ ላይ ነዉ፡፡\n\n~ ጆዲ ፒኩለት~",
                "ሰአቱን አትመልከት..ሰአቱ የሚያደርገዉን አድርግ፤ ወደፊት ብቻ ሂድ!\n\n~ሚካኤል ፎክስ~",
                "አስተማሪ አይደለሁም ግን ሰዉን ከእንቅልፉ አንቂ ነኝ\n\n~ሮበርት ፍሮስት~",
                "ቤተሰብህን አልመረጥካቸዉም፡፡ እነሱ የእግዚአብሄር ስጦታዎች ናቸዉ፡፡\n\n~ዴስሞንድ ቱቱ~",
                "ፃድቅ ሰዉ የቀድሞ ታሪክ አለዉ እርጉሙ ደግሞ የፊት ለፊት እጣ ይኖረዋል፡፡\n\n~ ኦስካር ዊልዴ~",
                "ማንንም በቆሻሻ እግሮቹ ጭንቅላቴ ላይ እንዲራመድ አልፈቅድለትም \n\n~ማህተመ ጋንዲ~" ,
                "ሌሎችን ለማሞቅ ብለህ እራስህን እሳት ላይ አትጣድ \n\n~ያልታወቀ ሰዉ~" ,
                "በህይወት ያለኸዉ ለጥቂት ጉብኝት ብቻ ነዉ፡፡አትቸኩል..አትጨናነቅ…በመንገድህ ያገኘሃቸዉን አበቦች ማሽተትህን አታቁም፡፡  \n\n~ዋልተር ሃገን~" ,
                "ህይወትን መገመት ቢቻል ኖሮ ህይወት መሆኑን ያቆምና ጣእም ያጣ ነበር፡፡ \n\n~ኢሌኖይር ሩዝቬልት~" ,
                "ረዥም ጊዜ በማንኪያ መመገባችን የሚያስተምረን አዲስ ነገር የለም፡፡ የማንኪያዉን ቅርፅ ግን ያስተምረናል፡፡ \n\n~ኢም ፎርስተር~" ,
                "ትምህርት ያለስርአት ከተሰጠ አደገኛ ሰይጣኖችን ያፈራል፡፡\n\n~ቺኤስ ሊዊስ~" ,
                "ስለምትጠላቸዉ ሰዎች እያሰብክ ለደቂቃ አትዋል፡፡ \n\n~ድዋይት ኢሲንሃወር~" ,
                "ዛፉን ሳትጠላ የዛፉን ስር ልትጠላ አትችልም፡፡ \n\n~ ማልኮም ኤክስ~" ,
                "ዝምታ በጣም ይጮሃል \n\n~ ሳራ ዴሰን~" ,
                "ሰዉ በታማኝነቱ ምክንያት ከተቀጣ ዉሸትን ይማራል \n\n~ክሪስ ጃሚ~" ,
                "እራስህ ማንበብ የማትፈልገዉን መፅሃፍ ለህፃን ልጅ ለመስጠት ሀሞት አይኑርህ፡፡\n\n~ጆርጅ በርናርድ ሾዉ~",
                "አካባቢህ ላይ ባሉት ቀሪ ዉብ ነገሮች ደስተኛ ሁን፡፡\n\n~አና ፍራንክ~",
                "ለማንም ሰው ምንም አትናገር፡፡ከተናገርክ ግን ሰውን ሁሉ ማጣት ትጀምራለህ፡፡\n\n~ጄዲ ሳሊንገር~",
                "ሁሌም ቢሆን ሰዎችን የሚያጓጉዝ የታሪክ ክፍል ይኖራል ፡፡\n\n~ጄኬ ሮውሊንግ~",
                "የማይገለን ከሆነ አስቂኝ ሰዎች ያደርገናል፡፡\n\n~ማሪያን ኬስ~",
                "ሰዉን ይቅር ስትል ትላንትን እየቀየርክ አይደለም ነገር ግን ነገህን  በእርግጥም ቀይረሃል\n\n~በርናርድ ሜልዘር~",
                "አንድ ነገር እናስታዉስ…አንድ መፅሃፍ፣አንድ እስኪርፕቶ፣አንድ ልጅና አንድ አስተማሪ አለምን ይቀይራሉ፡፡\n\n~ማላላ ዩሳፍዚ~",
                "ወጣት ለመሆን ብዙ ጊዜ ይፈጃል\n\n~ፓብሎ ፒካሶ~",
                "የምትወደዉን ነገር አግኝና ከዛ ከፈለገ ይግደልህ  \n\n~ቻርልስ ቡኮዉስኪ~" ,
                "ተስፋ የመቁረጥ የተለመደ ምልክቱ እራስን አለመሆን ነዉ  \n\n~ሶርን ኬርክጋርድ~" ,
                "ህይወት ከተላደልክበት ኑሮ ስትወጣ ይጀምራል \n\n~አኒያስ ኒን~" ,
                "በዚህ ሰአት ደስተኛ ሁን፡፡ይህ ጊዜ ያንተ ነዉ \n\n~ኦማር ካያም~" ,
                "በህይወት ደስተኛ ለመሆን ፍፁም መሆን አያስፈልግም  \n\n~አኔቴ ፉኒሴሎ~" ,
                "ሰዎች በግል ካላወቁህ ሁኔታዉን ከቁም ነገር አትቁጠረዉ  \n\n~ያልታወቀ ሰዉ~" ,
                "በራስህ መተማመን አለብህ! ያ ትልቁ ሚስጥር ነዉ  \n\n~ቻርሊ ቻፕሊን~" ,
                "የህይወቴ ምርጥ ምክር እንዲህ ይላል ማንም ሰዉ ምን እያደረገ እንደሆነ በትክክል አያዉቅም  \n\n~ሪኪ ገርቫኢስ~" ,
                "ሁሌም ከተሰማህ ስሜት በላይ ደግ ሁን  \n\n~ያልታወቀ ሰዉ~" ,
                "የሆነ ሰዉን ለመሆን መጣር እራስህን የምታባክንበት መንገድ ነዉ  \n\n~ኩርት ኮቤይን~" ,
                "አቋራጭ መንገድ ረጅም ሰአት ያዘገይሃል \n\n~ጄአርአር ቶኬይን~" ,
                "በጣም ከሚያስጠሉ ነገሮች ዉስጥ ካንጀትህ እየተከራከርክ እያለ ትክክል እንዳልሆንክ የገባህ ቅፅበት ነዉ፡፡ \n\n~ያልታወቀ ሰዉ~", "አለቃዬ የሚከፈለኝ ደሞዝ ትልቅ እንደሆነ በሰበከልኝ ቁጥር የምሰራዉ ስራ በጣም ብዙ እንደሆነ እሰብክለታለሁ፡፡\n\n~ኦስካር ዊልዴ~", "አንዳንድ ሰዎች እንደ ደመና ናቸዉ፡፡ልክ ሲሄዱ ቀኑ ብሩህ ይሆናል፡፡\n\n~ያልታወቀ ሰዉ~", "ህይወቴ ኤዲቲንግ ያስፈልገዋል፡፡\n\n~ሞርት ሳሀል~", "የመምራት ጥበቡ ‹ይሆናል› ሳይሆን ‹አይሆንም› ማለት ነዉ ምክንያቱም ለህዝብ ‹ይሆናል› ማለት በጣም ቀላል ነዉ፡፡ \n\n~ቶኒ ብሌር~", "አንዳንዴ እግዚአብሄር ምርጥ ናቸዉ ያልናቸዉን ፕላኖች ሳይቀር ለጥቅማችን ሲል ያስቀራቸዋል፡፡\n\n~ቶሚ ደንዲ~", "ብዙ እንዳወቅኩ የተሰማኝ ጊዜ ትንሽ አዉቄአለሁ፡፡ \n\n~ሮበርት ኦዉን~", "የምሞትበት ቀን ሲደርስ ፅዋዉን የምጠጣዉ እኔዉ ነኝ ስለዚህ እባካችሁ የራሴን ህይወት በምፈልገዉ መንገድ ልምራዉ፡፡\n\n~ጂሚ ሄንደሪክስ~", "10000 አይነት ዉጤት አልባ መንገዶችን አወቅኩ እንጂ አልወደቅኩም፡፡\n\n~ቶማስ ኤዲሰን~", "የፈላስፋነት ሚስጥሩ መነሻ ምንጮችን እንዴት መደበቅ እንደሚቻል ማወቁ ላይ ነዉ፡፡ \n\n~አልበርት እንስታይን~", "በህይወት ከባዱ ሀዘን እኛ ራሳችን የምንፈጥራቸዉ ናቸዉ፡፡\n\n~ሶፎክለሰ~", "አንድ ጊዜ ትኖራለህ ግን በትክክል ከኖርከዉ አንዱ በቂ ነዉ፡፡ \n\n~ሜ ዌስት~", "ምርጥ ጭንቅላቶች ስለ ሃሳቦች ይወያያሉ፣መካከለኛ ጭንቅላቶች ስለሁኔታዎች ሲያወሩ ትንንሽ ጭንቅላቶች ደግሞ ስለሰዎች ያወራሉ፡፡\n\n~ኤላኖር ሩዝቬልት~", "ማንነትህ በደንብ ስለሚናገር የምትለዉን ላዳምጥህ አልችልም \n\n~ራልፍ ዋልዶ ኢመርሰን~", "ባገኘኸዉ ነገር የማትረካ ከሆነ ወደፊት ምንም ብትሰራ አትረካም \n\n~ክሪስ ሎኩርቶ~", "የህይወት ግቦቻችንን ሂደት ኮከቦችን እንደመሳሪያ መጠቀም እንጂ በሚያልፉ የመርከብ መብራቶች ላይ ማድረግ አያዋጣንም \n\n~ኦማር ብራድሊ~", "በምድር ላይ ሶስት አይነት ሰዎች አሉ፤ምንም የማይንቀሳቀሱ፣የሚንቀሳቀሱና ሌላዉን የሚያንቀሳቅሱ \n\n~ሊ ኸንግ~", "አንዳንድ ሰዎች በሄዱበት ደስታን ያመጣሉ ሌሎቹ ደግሞ በሄዱ ቁጥር ደስታን ያመጣሉ  \n\n~ኦስካር ዊልዴ~", "ህይወት  ደስ ትላለች ሞት ደግሞ ሰላማዊ ነዉ በጣም አስቸጋሪዉ ነገር መተላለፊያ ድልድዩ ነዉ፡፡\n\n~ሊንክዲን ኮትስ~", "ከበቀሎች ሁሉ ምርጡ በቀል ራስህን ማሻሻል ነዉ፡፡\n\n~ኳይት ኮትስ~", "እኔ እያጋጠሙኝ ያሉ ነገሮች ዉጤት ሳልሆን የዉሳኔዬ ዉጤት ነኝ፡፡\n\n~ስቴፈን ኮቬይ~", "ሰዎች እንዳይወቅሱህ ከፈለክ ምንም አትስራ፣ምንም አታዉራ በአጭሩ ምንም ሁን፡፡\n\n~ኤልበርት ሁባርድ~", "የህይወትህ ደስታ የሚጀምረዉ በምታስባቸዉ የሃሳብ ልቀት ያህል ነዉ፡፡\n\nማርከስ ኦሪሊየስ", "እዉነተኛ ጓደኛ ነበረኝ  …አንድ ቀን ፊት ለፊት ወጋኝ፡፡\n" + "\n~ያልታወቀ ሰዉ~", "የአምስት አመት ልጅ እያለሁ እናቴ ሁልጊዜ መደሰት የህይወት ቁልፍ ነገር ነዉ ትለኛለች፤ትምህርት ቤት ዉስጥ ሰዎች ሳድግ ምን መሆን እንደምፈልግ ጠየቁኝ ‹‹ደስተኛ መሆን ››አልኩ፡፡ጥያቄዉ አልገባህም አሉኝ እኔም ህይወት አልገባችሁም አልኳቸዉ፡፡ \n" +
                "\n\n" +
                "\n~ጆን ሌኖን~", "ፀፀት ማንነትህን አይቀይረዉም ግን ይገልፀዋል፡፡ \n" +
                "\n\n" +
                "\n~ጆን ግሪን~", "ሰዎች ምን ያህል እንደምታስብላቸዉ እስካላወቁ ድረስ ስላንተ ጠቢብነት አይጨነቁም   \n" +
                "\n\n" +
                "\n~ጆን ሲ.ማክስዌል~", "ከዚህ በፊት ለማወቅ የማትፈልገዉን ነገር አሁን ላይ አትስራ!  \n" +
                "\n\n" +
                "\nቤንጃሚን ፍራንክሊን", "ስራዎችህ ሌሎችን እንዲያልሙ፣እንዲማሩ፣ብዙ እንዲሰሩና የሚፈልጉትን እንዲሆኑ ካደረጋቸዉ ምርጥ መሪ ነህ ማለት ነዉ  \n" +
                "\n\n" +
                "\n~ጆን ኩዊንሲ አዳምስ~", "ስለደረቀ ዛፍ እናወራለን የደረቀዉን ዛፍ ግን አናወራዉም! \n" +
                "\n\n" +
                "\n~ዜን ሻዉር~", "በጭንቅ ጊዜ መሄድ ከቻልክ አሁንም ዝም ብለህ ጉዞህን ቀጥል    \n" +
                "\n\n" +
                "\n~ሰር ዊንስተን ቸርችል~", "ህይወት ማለት መብረቁ እስኪያልፍ መጠበቅ ሳይሆን በዝናብ ዉስጥ እንዴት እንደምትደንስ ማወቅ ነዉ፡፡ \n" +
                "\n\n" +
                "\n~ቪቪያን ግሪን~", "የተለመደን አሰራር ባልተለመደ መንገድ ስትሰራ የአለምን ትኩረት ትስባለህ  \n" +
                "\n\n" +
                "\n~ጆርጅ ዋሽንግተን~", "ሰአቱ ማጠሩ ጎዳን እንጂ ጨዋታዉን አልተሸነፍንም  \n" +
                "\n\n" +
                "\n~ቪንስ ሎምባርዲ~", "እዉቀት ታወራለች ጥበብ ደግሞ ትሰማለች   \n" +
                "\n\n" +
                "\n~ጂሚ ሄንድሪክስ~", "ስለተናገርኩት ነገር ብዙ ጊዜ ይቆጨኛል ዝም ስላልኩበት ጉዳይ ግን ቆጭቶኝ አያዉቅም \n" +
                "\n\n" +
                "\n~ዜኖቅራጠስ~", "ሁሉ ነገር በቁጥጥር ስር እንደሆነ ከተሰማህ በፍጥነት እየሄድክ አይደለም \n" +
                "\n\n" +
                "\n~ማሪዮ አንድሬቲ~", "የሞትኩ እለት እተኛለሁ    \n" +
                "\n\n" +
                "\n~ዋረን ዝቮን~", "ነገሮችን ለሌላ ቀን ስናስተላልፍ ህይወት ራሷ ታልፈናለች   \n" +
                "\n\n" +
                "\n~ሴኔካ~", "ምክር ማለት የሰዎችን መልስ እያወቅን የምንጠይቀዉ ነገር ሲሆን ሁላችንም መልሱን ባናዉቀዉ ደስ ይለናል \n" +
                "\n\n" +
                "\n~ኤሪካ ጆንግ~", "እንዴት መኖር ይቻላል ከሚለዉ ጥያቄ ዉጪ ሁሉም ነገር መፍትሄ ተገኝቶለታል  \n" +
                "\n\n" +
                "\n~ጂን ፖዉል ሳርትሬ~", "የሚያወላዉል ሰዉ በጣም ጅል ሰዉ ነዉ  \n" +
                "\n\n" +
                "\n~ሜ ዌስት~", "ከትልቅ ሃብት ጀርባ ወንጀል አለ  \n" +
                "\n\n" +
                "\n~ሆኖር ዲ ባልዛክ~", "የጦርነት አላማዉ ለሃገርህ እንድትሞት ሳይሆን ጠላትህን ለሃገሩ እንዲሞት ማድረግ ነዉ፡፡ \n" +
                "\n\n" +
                "\n~ጀነራል ጆርጅ ፓቶን~", "ጓደኞች ይመጣሉ ይሄዳሉ ጠላቶች ግን ይከማቻሉ  \n" +
                "\n\n" +
                "\n~ቶማስ ጆንስ~", "በቁጣ የሚጀመር ነገር ሁሉ በእፍረት ይዘጋል  \n" +
                "\n\n" +
                "\n~ቤንጃሚን ፍራንክሊን~", "አንዳንዴ በጣም ጥሩ ናቸዉ የምትላቸዉ ሰዎች ቆዳቸዉ በንቅሳት የተሸፈነ ሲሆን በጣም አስቸጋሪ ሰዎች ደግሞ እሁድ እሁድ ቤተክርስቱያን የሚሄዱት ናቸዉ፡፡\n" +
                "\n\n" +
                "\n~ሊንክዲን ኮትስ~", "የራስህን ጥላ ካላየህ ብርሃን ላይ አይደለህም ማለት ነዉ፡፡ \n" +
                "\n\n" +
                "\n~ማሪሳ ሜየር~", "ከምንም በላይ የሚያስፈልግህ ነገር ቢኖር ፍርሃት ከሚባለዉ አለም በተቃራኒ መሆን ነዉ፡፡ \n" +
                "\n\n" +
                "\n~ጆርጅ አዳኤር~", "ዙሪያ ጥምጥም በምትሄድበት ጉዞ ላይ የትራፊክ መጨናነቅ የለም፡፡ \n" +
                "\n\n" +
                "\n~ሮገር ስታዉባክ~")

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen_slide)

        val statusBarSetting : Window = this.window
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){

            statusBarSetting.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            statusBarSetting.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            statusBarSetting.statusBarColor = ContextCompat.getColor(this,android.R.color.black)

        }


        mPager = findViewById(R.id.pager)
        myButton = findViewById(R.id.new_but)
        backgroundLayout = findViewById (R.id.backgroundImage)
        mAdView = findViewById(R.id.adView)

        mPagerAdapter = ScreenSlidePagerAdapter(supportFragmentManager)
        mPager.adapter = mPagerAdapter


        Glide.with(this).load(R.drawable.lovely).into(backgroundLayout)

        val adRequest = AdRequest.Builder().build()
        mAdView.loadAd(adRequest)


        myButton.setOnClickListener {

            val prefs = getPreferences(Context.MODE_PRIVATE)
            var clickCount = prefs.getInt(ContentOne.KEY_CLICK_COUNT,0)
            clickCount ++

            val sharingIntent = Intent(Intent.ACTION_SEND)
            sharingIntent.type = "text/plain"
            sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "ምቹ ስፍራ")
            sharingIntent.putExtra(Intent.EXTRA_TEXT,quoteContents[mPager.currentItem])
            startActivity(Intent.createChooser(sharingIntent, "ሼር ያድርጉ!"))
            prefs.edit().putInt(ContentOne.KEY_CLICK_COUNT,clickCount).apply()


        }
    }

    inner class ScreenSlidePagerAdapter(fm: FragmentManager) : FragmentStatePagerAdapter(fm) {


        private val mCount = quoteContents.size

        override fun getItem(position: Int): Fragment {

            return  ViewPagerAdapter.newInstance(quoteContents[position % quoteContents.size])
        }

        override fun getCount(): Int = mCount

    }


}
