package com.afc.qewachquotes

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import android.support.v4.content.ContextCompat
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.bumptech.glide.Glide


class ContentFive : FragmentActivity() {

    private lateinit var mAdView: AdView
    private lateinit  var mPager: ViewPager
    private lateinit var mPagerAdapter: PagerAdapter
    private var backgroundLayout: ImageView ?= null
    private lateinit var myButton : Button



    companion object {

        const val  KEY_CLICK_COUNT = "1"
        private val quoteContents = arrayOf(
                "ገንዘብን ያገኘሁት በተለመደዉ መንገድ ነዉ…ከመሞቱ በፊት ሁሉ ነገር ለነበረዉ ሃብታም ጎረቤቴ በጣም ጥሩ ሰዉ ነበርኩ፡፡ \n\n~ማልኮልም ፎርብስ~",
                "ሃብትህን ገንዘብህን በሙሉ አጥተህ አንተ ራስህ በምታወጣዉ ዋጋ ትለካዋለህ፡፡ \n\n~ያልታወቀ ሰዉ~", "ገንዘብ ክፉ አለቃ ግን ምርጥ ባሪያ ነዉ ፡፡\n\n~ፒቲ ባርነም~",
                "ሀብት ማለት ህይወትን በሙሉ በደምብ የማጣጣም ችሎታ ነዉ፡፡\n\n~ሄነሪ ዴቪድ~", "ገንዘብህን ተቆጣጠረዉ አለበለዚያ ያጣህ እለት ለዘላለም ይቆጣጠርሃል፡፡ \n\n~ዴቭ ራምሴይ~",
                "ገንዘብ በተበደርክ ቁጥር የወደፊት ማንነትህን እየዘረፍክ ነዉ፡፡\n\n~ናታን ደብሊዉ ሞሪስ~",
                "ብር ጓደኞችን ሊገዛልህ አይችልም ግን የተሻለ አመለካከት ያላቸዉ ጠላቶችን ያፈራልሃል፡፡ \n\n~ስፓይክ ሚሊጋን~",
                "የሰዉየዉ አእምሮ ከመጥበቡ የተነሳ በአንድ ቁልፍ ቀዳዳ በሁለቱም አይኖቹ ማየት ይችላል\n\n~ ሞሊ ኢቪንስ~",
                "ስሞት ልክ አያቴ እንደሞተዉ አይነት እንቅልፍ ይዞኝ ጭልጥ እንዲል እፈልጋለሁ፡፡አያቴ የተሳፈረበት መኪና ከመገልበጡ በፊት ሰዉ ሁሉ እየጮኸ ነበር\n\n~ ቦብ ዋንክሃዉስ~",
                "ሳይክል እንዲሰጠኝ ፀለይኩ፡፡ እግዚአብሄር ግን በኔ መንገድ ብቻ ፀሎቴን እንደማይመልስልኝ ስለተሰማኝ ሳይክሉን ሰርቄ ይቅርታ እንዲያደርግልኝ ጠየቅኩ\n\n~ኢሞ ፊሊፕስ~",
                "ደስተኛ ሆኜ ላደርጋቸዉ የምፈልጋቸዉ ነገሮች ወይ ህገወጥ ናቸዉ አለበለዚያ ደግሞ ሰዉ የሚሰራቸዉ ነገሮች አይደሉም\n\n~አሌክሳንደር ዎልኮት~",
                "ሰዎች ደዉልልኝ ብለዉ ሜሴጅ ሲያደርጉልኝ እናደዳለሁ፡፡ ከዛ ለሰዎቹ እደዉልና ስልኩን ሊያነሱት ሲሉ ጆሮአቸዉ ላይ ጠርቅሜ መልእክትህን ላክልኝ እልና ሜሴጅ አደርግለታለሁ፡፡\n\n~ፒኢንተረስት ኮትስ~",
                "ከአንድ ሰዉ ስትሰርቅ ኩረጃ ይባላል፡፡ከብዙ ሰዎች ስትሰርቅ ደግሞ ሪሰርች ይባላል፡፡\n\n~ዊልሰን ሚዝነር~",
                "ላንተ እሞታለሁ ግን ልኖርልህ አልችልም\n\n~ስቴፈን ቾብስኪ~",
                "ሰዎችን በማስረዳት ጊዜህን አታባክን፡፡ሰዎች መስማት የሚፈልጉት ለጆሮአቸዉ የሚጥማቸዉን ነገር ብቻ ነዉ፡፡\n\n~ፓዉሎ ኮሄሎ~",
                "አንድ ደቂቃ አርፍዶ ከመምጣት ሶስት ሰአት ቀድሞ መምጣት ይሻላል\n\n~ዊሊያም ሼክስፒር~",
                "እባክህ ጌታ ሆይ ሎተሪ ማሸነፍ ማንነቴን እንደማይቀይረዉ ላረጋግጥልህ ! \n\n~ያልታወቀ ሰዉ~" ,
                "ሰዎች ፍቅር ከገንዘብ ይበልጣል ይላሉ…ግን ልትከፍሉ ስትሉ የምትከፍሉትን ሰዉ አቅፋችሁት ብቻ ሄዳችሁ ታዉቃላችሁ?  \n\n~ያልታወቀ ሰዉ~" ,
                "ብዙ ገንዘብ እንዳለዉ  ደሃ ሰዉ ሆኜ መኖር እፈልጋለሁ \n\n~ፓብሎ ፒካሶ~" ,
                "ልጅ እያለሁ ገንዘብና ታዋቂ መሆን ትልቅ ደስታን ይፈጥራል ብዬ አምን ነበር፡፡ አሁን አድጌአለሁ እምነቴም ትክክል ነበር \n\n~ያልታወቀ ሰዉ~" ,
                "ለምንድነዉ አልባሌ ስፍራ እየሄድክ ገንዘብህን የምትጨርሰዉ?…እኔ ጋር  ና! \n\n~ያልታወቀ ሰዉ~" ,
                "ገንዘብ ጓደኞችን አይገዛልህም ነገር ግን የተሻሉ ጠላቶችን ያገናኝሃል  \n\n~ስፓይክ ሚሊጋን~" ,
                "ብልህ ሰዉ ገንዘቡን በጭንቅላቱ ዉስጥ እንጂ በልቡ ዉስጥ አያኖርም \n\n~ጆናታን ስዊፍት~" ,
                "ገንዘብ ብዙ ጊዜ ትልቅ ዋጋ ያስከፍላል  \n\n~ራልፍ ዋልዶ~",
                "መቼም ቢሆን ማግኘት እየቻልክ ለመለመን ሃሞቱ አይኑርህ! \n\n~ሚጉዌል ዲ ሰርቫንቴስ~" ,
                "ብዙ ጊዜ ገንዘብ በሰዎች ተወድዶ እንጂ ተፈልጎ አያዉቅም  \n\n~ጂም ሮን~",
                "ተኝተህ ገንዘብ ማግኘትህን እስካላረጋገጥክ ድረስ አልጋህ ላይ አትዋልበት  \n\n~ጆርጅ በርንስ~", "ብልህ ሰዉ ገንዘብን በልቡ ዉስጥ ሳይሆን በጭንቅላቱ ዉስጥ ያስቀምጣል፡፡\n\n~ጆናታን ስዊፍት~",
                "ትምህርት ቤት ዉስጥ መማር ለመኖር የሚያስፈልግህን ነገር ያሟላልሃል እራስህን በራስህ ማስተማር ደግሞ ሀብታም እንድትሆን ያደርግሃል፡፡ \n\n~ጂም ጆን~",
                "ገንዘብ መጠቀሚያ መሳሪያ ብቻ ነዉ፣የፈለክበት ቦታ ይወስድሃል ግን አንተነትህን አይተካዉም፡፡\n\n~አይን ራንድ~",
                "መቼም ቢሆን ገንዘብ በራሱ ለሰዉ ደስታን ሰጥቶት አያዉቅም ወደፊትም አይሰጠዉም፡ ሰዉ ገንዘቡ በጨመረ ቁጥር ሌላ ትልቅ ገንዘብ ይፈልጋል፡፡ \n\n~ቤንጃሚን ፍራንክሊን~",
                "ብዙ ጊዜ ገንዘብ ትልቅ ዋጋ ያስከፍላል፡፡\n\n~ራልፍ ዋልዶ ኢመርሰን~", "ትልቅ ብር ያለዉ ሳይሆን ብዙ የሚሰጥ ሀብታም ይባላል፡፡ \n\n~ኤሪች ፍሮም~",
                "የምትፈልገዉን ነገር ማግኘት እየቻልክ መቼም ቢሆን ቆመህ አትለምን፡፡ \n\n~ሚግዌል ዲ ሰርቫንቴስ~", "መኖር የምፈልገዉ ብር እንዳለዉ ደሃ ሰዉ ነዉ፡፡\n\n~ፓብሎ ፒካሶ~",
                "ስለገንዘብ ጥያቄ ሲነሳ ሁሉም ሰዉ አንድ አይነት ሃይማኖት ይኖረዋል፡፡\n\n~ቮልቴር~",
                "ገንዘብ ወይም ልብስ ቢኖርህም ባይኖርህም ዋጋ የለዉም፤በህይወትህ መጨረሻ ላይ ለብቻህ ትቀራለህ፡፡ \n\n~ቢሊ አይዶል~",
                "ጥበብ ያለዉ ገንዘብ ማግኘቱ ላይ ሳይሆን ገንዘብ መቆጠቡ ላይ ነዉ፡፡ \n\n~ምሳሌ~", "ለኔ ምርጥ የሆነ አንድ ሃሳብ ከገንዘብ በላይ ነዉ፡፡ \n\n~ቶማስ ጀፈርሰን~",
                "ሁሉንም እንቁላሎች በአንድ ቅርጫት አስቀምጠህ ቅርጫቱን በደንብ ጠብቅ፡፡ \n\n~አንድሪዉ ካርንጌ~", "ገንዘብ የነበረኝ ሰአት ሁሉም ሰዉ ‹ወንድም› እያለ ይጠራኝ ነበር፡፡ \n\n~የፖሊሽ ምሳሌያዊ አነጋገር~",
                "እዉቀት ለማግኘት ብዙ ገንዘብህን ካፈሰስክ ከፍተኛ ወለድ ታገኛለህ፡፡ \n\n~ቤንጃሚን ፍራክሊን~",
                "ገንዘብህን አፍስሰህ የተመቸ የምትለዉን መንገድ ስትከተል ትርፍህን ጥቂት ታደርገዋለህ፡፡\n\n~ሮበርት አርኖት~",
                "ገንዘብን አምላክህ አድርገዉ ከዛ እንደሰይጣን መቅሰፍት ይሆንብሃል፡፡ \n\n~ሄንሪ ፊልዲንግ~",
                "ገንዘብ በአለም ላይ በጣም ከሚያስፈልጉ ነገሮች ዉስጥ ዋነኛዉ አይደለም፡፡ዋናዉ ፍቅር ነዉ.ስለዚህ እኔም ገንዘብ አፈቅራለሁ፡፡ \n\n~ጃኪ ሜሰን~",
                "ጥቁር ሆንክ ነጭ ምንም ዋጋ የለዉም፤ትልቅ ልዩነት የሚያመጣዉ ቀለም አረንጓዴ ነዉ፡፡ \n\n~ፋሚሊ ጋይ~",
                "የገንዘብን ጥቅም ማወቅ ከፈለክ ሂድና ትንሽ ብር ተበደር፡፡ \n\n~ቤንጃሚን ፍራንክሊን~",
                "ገንዘብህን እጥፍ ለማድረግ አስተማማኙ መንገድ አጣጥፎ ቦርሳ ዉስጥ ማስቀመጥ ነዉ፡፡ \n\n~ኪን ሀባርድ~",
                "ትክክለኛዉን ነገር ስትሰራ ገንዘብ ያለህበት ድረስ ፈልጎህ ይመጣል፡፡ \n\n~ማይክ ፊሊፕስ~",
                "ደስታን ሊያመጣ የሚችለዉን ነገር በትክክል ለማወቅ ይከብዳል፡፡ ምክንያቱም ድህነትና ሀብት ከደስታ ጋር ተቀያይመዋል፡፡\n\n~ኪን ሀባርድ~",
                "በጣም ብዙ ሰዎች ካገኙት መጠን በላይ ገንዘብ ያወጣሉ፣የማይፈልጉትን ነገር ይገዛሉ ከዛም የማይወዱትን ሰዉ ለማስደመም ይጥራሉ፡፡ \n\n~ዊል ስሚዝ~",
                "ገንዘብ ምርጥ ዶድራንት ነዉ፡፡ \n\n~ኤልዛቤት ታይለር~", "ብርህን እጅህ ዉስጥ ከማስገባትህ በፊት መቼም አትጠቀምበት፡፡\n\n~ቶማስ ጄፈርሰን~",
                "ህግ 1፡ ገንዘብህን አታባክን ህግ 2፡ ህግ አንድን መቼም እንዳትረሳዉ\nዋረን በፌት",
                "ትናንሽ ወጪዎችህን ተጠንቀቃቸዉ ምክንያቱም ትንሽ ቀዳዳ ትልቅ መርከብን የማስጠም ሃይል አላት፡፡ \n\n~ቤንጃሚን ፍራንክሊን~",
                "ገንዘብ ሁሉንም ነገር ያደርጋል ብለህ አታስብ ያለበለዚያ ለገንዘብ ብለህ ሁሉንም ነገር ታደርጋለህ፡፡ \n\n~ቮልቴር~",
                "ገንዘብ ያላቸዉ ሰዎች አሉ፣ሀብታም የሆኑ ሰዎችም አሉ፡፡ \n\n~ኮኮ ቻንል~",
                "የገንዘብ ቦርሳዬ ልክ እንደ ሽንኩርት ነዉ..ስከፍተዉ ያስለቅሰኛል፡፡\n\n~የማይታወቅ ሰዉ~",
                "ሰዎች ፍቅር ከገንዘብ የበለጠ ነዉ ይላሉ ግን የቤት ወጪዉን ሰዉ ለመክፈል ሲሄድ ገንዘብ ተቀባዩን እቅፍ አርጎ ሰላም በማለት ሳይከፍል መሄድ ይችላለህ.. \n\n~የማይታወቅ ሰዉ~",
                "አሁንስ አይኔን ያዝ እያረገኝ ነዉ…ካገባሁ ጀምሮ ቤቴ ዉሰጥ ምንም አይነት ብር አይቼ አላዉቅም \n\n~ኩል ፈኒ ኮትስ~", "ገንዘብ ደስተኛ አያደርግህም..አሁን 50 ሚሊየን ዶላር አለኝ ግን ደስታዬ 48 ሚሊየን ዶላር እንደነበረኝ ጊዜ ያዉ ነዉ \n\n~አርሎንድ ሸዋዚንገር~", "ጌታ ሆይ እባክህ ሎተሪ ወጥቶልኝ ፀባዬ እንደማይቀያየር ላረጋግጥልህ፡፡ \n\n~የማይታወቅ ሰዉ~", "እኔ ኒልየነር ነኝ..ወይ ጥቂት ብር አለኝ ወይም ምንም የለኝም  \n\n~ያልታወቀ ሰዉ~", "አባት ሲተረጎም ድሮ ገንዘብ በሚያስቀምጥበት ቦርሳ ዉስጥ አሁን ፎቶ ይዞ የሚዞር ሰዉ ማለት ነዉ፡፡ \n\n~ያልታወቀ ሰዉ~", "ስለሃብታም ሰዎች ከተወራ አንድ ነገር ብቻ እወድላቸዋለሁ…ገንዘባቸዉን! \n\n~ናንሲ አስተር~", "ዕጣ ወጥቶልህ ያገኘኻዉ ገንዘብ ለፍተህ ካገኘኸዉ ይልቅ ይጣፍጣል፡፡ \n\n~ፖል ኒዉማን~", "ገንዘብ ማዉራት ሲጀምር ማንም ሰዉ ስለሚደመጠዉ የንግግር ስልት አይጨነቅም፡፡ \n\n~ሮበርት ኢሊየት~", "እምነትህን ገንዘብ ላይ አትጣል ግን ገንዘብህን የሚታመን ቦታ አስቀምጥ፡፡ \n\n~ኦሊቨር ዌንድል~", "ጓደኝነትና ገንዘብ ዘይትና ዉሃ ናቸዉ፡ \n\n~ማሪያ ፐሪንስ~")

    }

override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_screen_slide)

    val statusBarSetting : Window = this.window
    if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){

        statusBarSetting.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        statusBarSetting.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        statusBarSetting.statusBarColor = ContextCompat.getColor(this,android.R.color.black)

    }


    mPager = findViewById(R.id.pager)
    myButton = findViewById(R.id.new_but)
    backgroundLayout = findViewById (R.id.backgroundImage)
    mAdView = findViewById(R.id.adView)

    mPagerAdapter = ScreenSlidePagerAdapter(supportFragmentManager)
    mPager.adapter = mPagerAdapter

    Glide.with(this).load(R.drawable.birr).into(backgroundLayout)

    val adRequest = AdRequest.Builder().build()

    mAdView.loadAd(adRequest)

    myButton.setOnClickListener {

        val prefs = getPreferences(Context.MODE_PRIVATE)
        var clickCount = prefs.getInt(ContentOne.KEY_CLICK_COUNT,0)
        clickCount ++

        val sharingIntent = Intent(Intent.ACTION_SEND)
        sharingIntent.type = "text/plain"
        sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "ገንዘብ..")
        sharingIntent.putExtra(Intent.EXTRA_TEXT, quoteContents[mPager.currentItem])
        startActivity(Intent.createChooser(sharingIntent, "ሼር ያድርጉ!"))
        prefs.edit().putInt(ContentOne.KEY_CLICK_COUNT,clickCount).apply()


    }
}

    inner class ScreenSlidePagerAdapter(fm: FragmentManager) : FragmentStatePagerAdapter(fm) {


        private val mCount = quoteContents.size

        override fun getItem(position: Int): Fragment {

            return  ViewPagerAdapter.newInstance(quoteContents[position % quoteContents.size])
        }

        override fun getCount(): Int = mCount

    }


}
