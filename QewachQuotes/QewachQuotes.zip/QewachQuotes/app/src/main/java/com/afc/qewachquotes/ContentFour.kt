package com.afc.qewachquotes

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import android.support.v4.content.ContextCompat
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.bumptech.glide.Glide


class ContentFour : FragmentActivity() {

    private lateinit var mAdView: AdView
    private lateinit  var mPager: ViewPager
    private lateinit var mPagerAdapter: PagerAdapter
    private var backgroundLayout: ImageView ?= null
    private lateinit var myButton : Button


    companion object {

        const val  KEY_CLICK_COUNT = "1"
        private val quoteContents = arrayOf(
                "የሴቶች ችግር ምንም ነገር ሳይደንቃቸዉና ሳያስደስታቸዉ ትዳር ይይዛሉ፡፡\n\n~ቼር~",
                "ብዙ ሰዎች ትዳር የተሰራዉ ገነት ዉስጥ ነዉ ይላሉ፡፡ ነገር ግን ትዳር ብቻ ሳይሆን መብረቅም እዛዉ ገነት ዉስጥ ነዉ የተሰራዉ\n\n~ክሊንት ኢስትዉድ~",
                "ትዳር ራሳችንን ለማሳደግ የመጨረሻዉና  ምርጡ እድላችን ነዉ፡፡ \n\n~ጆሴፍ ባርዝ~" ,
                "አንድ ብርጭቆ  ወይን የአንድ ሰአት ደስታ ይሰጣል፤ትዳር  የአንድ አመት ደስታ ይሰጣል፡አበቦች ከተከልክ ደግሞ የእድሜ ልክ ደስታ!  \n\n~የቻይኖች አባባል ~" ,
                "ትዳር ማለት ሶስት ክፍሉ ፍቅርን  ሰባት ክፍሉ ደግሞ ይቅርታን የያዘ ቤት ነዉ  \n\n~ያልታወቀ ሰዉ~" ,
                "ሰዎች በህይወታቸዉ ደስተኛ ከሆኑ በትዳራቸዉም ደስተኞች ይሆናሉ \n\n~ፊሊስ ባቴሌ~" ,
                "በትዳር ዉስጥ በጣም አስፈላጊዉ ነገር ደስታ ሳይሆን ተቻችሎ መኖር ነዉ \n\n~ገብሬል ጋርሲያ~" ,
                "በማፍቀሩ ደሃ የሆነ ማነዉ?  \n\n~ኦስካሪ ዊልዴ~" ,
                "ቤተሰብ ማለት ጠቃሚ የሆነ ነገር አይደለም፤ ቤተሰብ ሁሉ ነገር ነዉ፡፡\n\n~ሚካኤል ፎክስ~",
                "በደስታ ይኖሩ ጀመር የሚለዉ ቃል ተረት ሳይሆን ምርጫ ነዉ  \n\n~ፋዉን ዊቨር~" ,
                "ሰዎች ተጋብተዉ በዛዉ የሚቀሩት ስለፈለጉ ነዉ እንጂ  በሩ ስለተከረቸመባቸዉ አይደለም \n\n~ፓዉል ኒዉማን~" ,
                "ፍቅር ሃሳባዊ ሲሆን ትዳር ግን ተግባራዊ ነገር ነዉ \n\n~ጆአን ዉልፍጋንግ~" ,
                "ባለትዳሮች መንገድ ላይ ሲሄዱ ካየህ ቀደም ቀደም የሚለዉ በጣም የተበሳጨዉ ሰዉ ነዉ፡፡ \n\n~ሄለን ሮዉላንድ~" ,
                "እኔና ሚስቴ ለሃያ አመት በደስታ ኖርን ከዛ ተገናኘን  \n\n~ያልታወቀ ሰዉ~" ,
                "በትዳር ዉስጥ በጣም ትልቁ ንግግር እኔ ሳህኖቹን አጥባለሁ የሚለዉ አባባል ነዉ \n\n~ያልታወቀ ሰዉ~",
                "ስኬታማ ባል ሚስቱ ከምታወጣዉ ወጪ በላይ የሚያገኝ ሰዉ ነዉ፡፡ስኬታማ ሴት ደግሞ ይህንን ሰዉ ያገባችዉ ነች! \n\n~ላና ተርነር~",
                "እንደምንም ብለህ አግባ፡፡ጥሩ ሚስት ካገኘህ ደስተኛ ትሆናለህ፤ክፉ ሚስት ካገባህ ደግሞ ፈላስፋ ትሆናለህ፡፡\n\n~ሶቅራጠስ~",
                "ከማግባቴ በፊት ልጆች እንዴት እንደሚኖረኝ 6 ቲዎሪ ነበረኝ፤አሁን ደግሞ የ6 ልጆችና የባዶ ቲዎሪ ባለቤት ነኝ፡፡\n\n~ጆን ዊልሞት~",
                "ቁጣ በዘር ይተላለፋል እሱንም ከልጆችህ ታገኘዋለህ፡፡\n\n~ሳም ሌቨንሰን~",
                "ተጋብቶ መኖርን የመሰለ ነገር የለም…በቀረዉ የህይወት ዘመንህ ሁሉ የምታናድደዉን ሰዉ ማግኘት በጣም ደስ ይላል!!\n\n~ትሩዝ ኮትስ~",
                "ሚስትህ እንድታዳምጥህ ከፈለክ ከሌላ ሴት ጋር አዉራ…ከዛማ ጆሮዋን ሁሉ ትሰጥሃለች፡፡ \n\n~ሲግመንድ ፍሮይድ~",
                "ተሳስተህ ዝም ካልክ ትክክል ሰርተሃል ፤ግን ትክክል ሆነህ ዝም ካልክ አግብተሃል ማለት ነዉ፡፡\n\n~ኳይት ኮትስ~",
                "20 ብር ቢኖርህና ሚስትህ 5 ብር ቢኖራት ሲደመር  ሚስትህ 25 ብር ይኖራታል…\n\n~ትሩዝ ኮትስ~",
                "ለብዙ አመታት ሚስቴን ምንም አልተናገርኳትም፤ለምን መሰለህ እሷ እየተናገረች ማቋረጥ አልፈለኩም፡፡\n\n~ሮድኔይ ዳነገርፊልድ~",
                "ማግባቴ ተመችቶኛል ምክንያቱም በህይወቴ ዘመን ሁሉ የማበሽቀዉን ሰዉ ማግኘቴ ደስታን ፈጥሮብኛል፡፡\n\n~ሪታ ረንደር~",
                "ሚስቴ ሰርቼ የማገኘዉን ገንዘብ ሁሉ ትወስዳለች፤እኔ ደግሞ ሁሌ ጠዋት ጠዋት ፖምና ንፁህ ልብስ አገኛለሁ፡፡\n\n~ሬር ሮማኖ~",
                "ስኬታማ ትዳር ከአንድ ሰዉ ጋር ብቻ ብዙ ጊዜ በፍቅር መዉደቅን ይፈልጋል \n\n~ሚግኖን ማክላሊን~",
                "ለሴት ልጅ እንደ አርኪዮሎጂስት የሚመች ባል አታገኝም..ባረጀች ቁጥር ባሏ እየወደዳት ይሄዳል ፡፡\n\n~አጋታ ክርስቴ~",
                "የተጋባችሁበትን ቀን ባልሽ እንዲያስታዉስ ከፈለክሽ በልደት ቀኑ አግቢዉ \n\n~ሲንዲ ጋርነር~",
                "ሴቶች ከጋብቻ በኋላ ወንድ ልጅ ይቀየራል ብለዉ ያስባሉ ግን አይቀየርም፣ወንዶች ደግሞ ሴት ልጅ እንዳገኘኋት ጊዜ ትሆናለች ብለዉ ያስባሉ ግን ትቀየራለች   \n\n~ቤቲና አርንት~",
                "መናፈሻ በር ላይ ፍቅር አትስራ…ምክንያቱም ፍቅር እውር ቢሆንም ጎረቤቶችህ እዉር አይደሉም  \n\n~ያልታወቀ ሰው~",
                "ሴቶች ባይፈጠሩ በምድር ላይ ያለዉ ገንዘብ ሁሉ ዋጋ ያጣ ነበር \n\n~አርስቶትል ኦናሲስ~",
                "እባክህ ትራፊክ.. እየነዳዉ ሞባይል ስላናገርኩ ልትቀጣኝ አይገባም!..የደወለችዉ ሚስቴ ናት…በአጭሩ አዳማጭ ነበርኩ! \n\n~ሊንክዲን ኮትስ~",
                "አንድ ሴት ከማግባትህ በፊት አንድ ኮምፒዉተር ከቀርፋፋ ኢንተርኔት ጋር ስጣትና የትግስቷን ሃይል እየዉ፡፡\n\n~ዊል ፈርል~",
                "ወንድ ልጅ በትክክል አገባ የሚባለዉ ሚስቱ ያልተናገረችዉን ነገር ሁሉ ሲረዳ ነዉ፡፡\n\n~ሎልሪዮት~",
                "የደስተኛ ጋብቻ ሚስጥሩ ሚስጥር ሆኖ ይኖራል፡፡\n\n~ሎልሪዮት~",
                "ከሚስቱ ጋር ከመተኛቱ በፊት ቤቱን እንዲያፀዳ ትእዛዝ እንደተሰጠዉ ባል ያህል በፍጥነት የሚያፀዳ ሰዉ አይገኝም \n\n~ስማይል ኮትስ~",
                "ልጄ ሆይ ዉበት ሳይሆን የዉስጥ ማንነትሽ ባልሽን በፍቅር ይጥለዋል፡፡ \n\n~ኢዉሪፒድሰ~",
                "ፍቅር ሃሳባዊ ነገር ነዉ፣ ትዳር ግን በገሃድ ያለ ነዉ \n\n~ቮን ጎቴ~",
                "ያለፍቅር ትዳር እንደሚኖር ሁሉ ያለትዳር ፍቅርም አለ  \n\n~ቤንጃሚን ፍራንክሊን~",
                "ትዳር በገነት ተሰርቶ በምድር የምንጠቀምበት ነገር ነዉ \n\n~ጆን ሊሊ~",
                "በምድር ላይ ትልቁ ደስታ ትዳር ነዉ፡፡ \n\n~ዊልያም ሌዮን~",
                "ትዳር አሪፍ ተቋም ነዉ፡፡እኔ ግን ለዚህ ተቋም ዝግጁ አይደለሁም \n\n~ሜ ዌስት~",
                "የትዳር ትልቁ መሰረት የጋራ ስምምነት አለማድረግ ነዉ፡፡ \n\n~ኦስካር ዊልዴ~",
                "ምርጥ ትዳር የሁለት ይቅር ባዮች አንድነት ነዉ፡፡\n\n~ሩት ቤል ግርሃም~",
                "እዉነተኛ ጓደኛ ያገኘ ደስተኞ ሆኖ ይኖራል..ሚስቱ እዉነተኛ ጓደኛ የሆነችለት ሰዉ ደግሞ የበለጠ ደስተኛ ይሆናል! \n\n~ፍራንዝ ሹበርት~",
                "ከችሎታዬ ዉስጥ ትልቅ ዉጤት ያስገኘልኝ ነገር ቢኖር እኔን እንድታገባ ሚስቴን ማሳመኔ ነዉ፡፡ \n\n~ዊንስተን ቸርችል~",
                "እንዳገባች ሴት አይነት ለቤተሰቧ ከልቧ የምትኖር ነፍስ ካገባ ወንድ አይገኝም  \n\n~ኦስካር ዊልዴ~",
                "ወንድ እስካላገባ ድረስ ፍቅሩን ሙሉ አያደርገዉም፣ሲያገባ ብቻ ሙሉነቱን ያረጋግጣል፡፡ \n\n~ዛዛ ጋቦር~",
                "ለብዙ አመታት ቀለበቴ ስራዉን ሲሰራ ቆይቷል..ፈተና ዉስጥ እንዳልገባ አስተምሮኛል..ብዙ ፓርቲዎች ላይ ሰአቱ ስላለፈ ወደቤት የመሄጃ ጊዜ ነዉ ብሎ አስታውሶኛል \n\n~ኤርማ ቦምቤክ~",
                "'በደስታ ይኖሩ ነበር' የሚለዉ ቃል ተረት ተረት ሳይሆን ምርጫ ነዉ  \n\n~ፋዉን ዌቨር~", "ሰዎች ተጋብተዉ የሚቀሩት  ስለፈለጉ እንጂ በሩ ስለተቆለፈ አይደለም \n\n~ፖዉል ኒዉማን~",
                "ፍቅር ለሰዉ ስትሰጥ ትልቁ ስጦታ ሲሆን ስትቀበል ደግሞ ትልቁ ኩራት ነዉ \n\n~ፋዉን ዊቨር~",
                "ምርጥ ትዳር ብዙ መሰራት የሚፈልግ ተግባር እንጂ ከመሬት ተነስቶ የሚከሰት አስማት አይደለም \n\n~ፋዉን ዊቨር~",
                "መጀመሪያ ይቅርታ የሚጠይቅ ሰዉ ጀግና ነዉ፣መጀመሪያ ይቅር የሚል ሰዉ ጠንካራ ነዉ፣ቀድሞ የሚረሳ ደግሞ ደስተኛ ነዉ \n\n~ያልታወቀ ሰዉ~",
                "እሳቱን በትዳርህ ዉስጥ እንዲነድ አድርግ ከዛ ህይወትህ ይሞቃል \n\n~ፋዉን ዊቨር~",
                "ያገባኸዉ አንድ ሰዉ ሳይሆን ሶስት ሰዉ ነዉ እነሱም በአእምሮህ የሳልካት ሴት፣የሴቷ ያሁን ማንነቷና አንተን በማግባቷ ምክንያት የምትላበሰዉ ማንነት ናቸዉ፡፡ \n\n~ሪቻርድ ኒድሃም~",
                "ትዳርህ በፍቅር እንዲሞቅ ከፈለክ ስትሳሳት ስህተትህን እመን፣ትክክል ስትሆን ደግሞ ዝም በል፡፡ \n\n~ኦግድን ናሽ~",
                "ትዳር ደስተኛ አያደርግህም፣አንተ ግን ትዳርህን ደስተኛ ማድረግ ትችላለህ \n\n~ዶ/ር ሌስ~",
                "ለሷ ጠቃሚ ከሆነ ለኔም ጠቃሚ ነዉ  \n\n~ግሬግ ፕሮቫንስ~", "አብረዉ የሚፀልዩ ጥንዶች አብረዉ ይቆያሉ\n\n~ያልታወቀ ሰዉ~",
                "ነገን እንደማታይ አድርገህ ዉደድ..ነገን ካየህ ደግመህ ዉደድ \n\n~ማክስ ሉካዶ~",
                "ለአዲስ ሙሽሮች የተሰጠ ጥቅስ ‹እኛ የእድሜ ልክ ኮንትራት ፈርመን በስራ ላይ የተሰማራን ሰዎች ነን› \n\n~ፊሊስ ኮስ~",
                "አባት ለልጆቹ ማድረግ ከሚገባዉ ነገር በጣም ጠቃሚዉ ሚስቱን መዉደዱ ነዉ  \n\n~ቴዎድር ሄስበርግ~",
                "ከሞት የበለጠ ነገር ምክንያታዊነት ሳይሆን ፍቅር ነዉ! \n\n~ሜጊ ሬይስ~")

    }


override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_screen_slide)

    val statusBarSetting : Window = this.window
    if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){

        statusBarSetting.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        statusBarSetting.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        statusBarSetting.statusBarColor = ContextCompat.getColor(this,android.R.color.black)

    }


    mPager = findViewById(R.id.pager)
    myButton = findViewById(R.id.new_but)
    backgroundLayout = findViewById (R.id.backgroundImage)
    mAdView = findViewById(R.id.adView)

    mPagerAdapter = ScreenSlidePagerAdapter(supportFragmentManager)
    mPager.adapter = mPagerAdapter

    Glide.with(this).load(R.drawable.happy).into(backgroundLayout)

    val adRequest = AdRequest.Builder().build()
    mAdView.loadAd(adRequest)


    myButton.setOnClickListener {

        val prefs = getPreferences(Context.MODE_PRIVATE)
        var clickCount = prefs.getInt(ContentOne.KEY_CLICK_COUNT,0)
        clickCount ++

        val sharingIntent = Intent(Intent.ACTION_SEND)
        sharingIntent.type = "text/plain"
        sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "ሴቶች..")
        sharingIntent.putExtra(Intent.EXTRA_TEXT, quoteContents[mPager.currentItem])
        startActivity(Intent.createChooser(sharingIntent, "ሼር ያድርጉ!"))
        prefs.edit().putInt(ContentOne.KEY_CLICK_COUNT,clickCount).apply()


    }
}

    inner class ScreenSlidePagerAdapter(fm: FragmentManager) : FragmentStatePagerAdapter(fm) {

        private val mCount = quoteContents.size

        override fun getItem(position: Int): Fragment {

            return  ViewPagerAdapter.newInstance(quoteContents[position % quoteContents.size])
        }

        override fun getCount(): Int = mCount

    }

}
