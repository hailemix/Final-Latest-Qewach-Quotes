package com.afc.qewachquotes

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import android.support.v4.content.ContextCompat
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.bumptech.glide.Glide


class ContentNine: FragmentActivity() {

    private lateinit var mAdView: AdView
    private lateinit  var mPager: ViewPager
    private lateinit var mPagerAdapter: PagerAdapter
    private var backgroundLayout: ImageView ?= null
    private lateinit var myButton : Button


    companion object {

        const val  KEY_CLICK_COUNT = "1"
        private val quoteContents = arrayOf(

                "እግዚአብሄር ስለገንዘብ ምን እንደሚያስብ ማወቅ ትፈልጋለህ? ገንዘቡን የሰጣቸዉን ሰዎች እስኪ አንዴ ተመልከት!\n\n~ ዶርቲ ፓርከር~",
                "አንድ የተገለጠልኝ ነገር ቢኖር የቤተሰብህን አባል ለመከራከርና ለማሸነፍ ከፈለግክ አፋቸዉ ዉስጥ ምግብ መኖሩን አረጋግጥ\n\n~ኬኔዝ ኮል~",
                "የመረጥከዉን ሰዉ ከማግባትህ በፊት አንድ ነገር ታደርጋለህ፡፡የምታገባትን ሴት ቀርፋፋ ኢንተርኔት እንድትጠቀም ታደርግና የዉስጥ ማንነቷን ትገነዘባለህ፡፡ \n\n~ዊል ፌሬል~",
                "የድሮዋ ፍቅረኛህ ‹እንደኔ አይነት ሰዉ መቼም ቢሆን አታገኝም!› ስትልህ ‹እሱን አይደል የምፈልገዉ!› በላት" + " \n\n~ስማይል ኮትስ~",
                "ልክ እንደ አጎቴ ሚሊየነር መሆን እፈልጋለሁ..አጎቴም ሚሊየነር መሆን ይፈልጋል  \n\n~ኩልፈኒ ኮትስ~",
                "ሰዎች ፈተና ሲፈተኑ ወደላይ ካዩ ሲያስታዉሱ፣ወደታች ካዩ ተስፋ ሲቆርጡ፣ወደግራና ወደ ቀኝ ካዩ ደግሞ ሲኮርጁ ነዉ፡፡  \n\n~ፈኒ ኮትስ~",
                "ሌባ ሁሉም ሰዉ እንደሚሰርቅ ያምናል  \n\n~ያልታወቀ ሰዉ~", "እረፍት ስሆን ብቻ ስራዬን እወደዋለሁ  \n\n~ኩልፈኒ ኮትስ~",
                "ማግባት እንደማልፈልግ ብነግረዉም ጭቅጭቁን ያልቻልኩት እንድ ሽማግሌ ጎረቤቴ የሆነ ሰርግ ላይ ተጠርተን ‹ቀጣዩ ሙሽራ አንተ ትሆናለህ ›ብሎ  አናደደኝ…በሌላ ጊዜ ሰዉ ሞቶ የቀብር ስነስርአት ላይ አግኝሁትና ‹ቀጣዩ ሰዉ አንተ ነህ›አልኩት፡፡  \n\n~ዘቶፕ ቴንስ~",
                "ሁልጊዜ ከእንቅልፌ ተነስቼ የአለም ሀብታም ሰዎችን የስም ዝርዝር ከፎርብስ መፅሄት አነባለሁ…አንብቤ ስጨርስ ስሜን ከዝርዝሩ ዉስጥ ካጣሁት ተነስቼ ወደስራ እሄዳለሁ   \n\n~ሮበርት ኦርብን~",
                "የሰዉ ልጅ ጭንቅላት በጣም አስገራሚ ነዉ፡፡ከተወለደበት ጊዜ ጀምሮ በደምብ ሲሰራ ይቆይና ድንገት ህዝብ በተሰበሰበበት ቦታ ማዉራት ሲጀምር ማሰብ ያቆማል፡፡  \n\n~ጆርጅ ጅስል~",
                "ዝግመተ ለዉጥ እዉነት ከሆነ እናቶች ለምን ሁለት እጅ ብቻ ይኖራቸዋል…?  \n\n~ሚልተን በርሌ~", "ያለፈ ታሪክህ እያንኳኳ ክፈትልኝ ቢልህ እንዳትከፍትለት!ምንም አዲስ ነገር አይነግርህም!  \n\n~ፈኒ ኮትስ~",
                "አሜሪካ ማለት ግማሹን ብርህን ምግብ ለመግዛት ተጠቅመህ የቀረዉን ግማሽ ደግሞ ክብደት ለመቀነስ የምታዉልበት ሀገር ነዉ፡፡  \n\n~ያልታወቀ ሰዉ~", "ሁለት ነገሮች ብቻ የሴቶችን ስሜት ይለዉጣሉ \n1. አፈቅርሻለሁ  \n 2. 50 % ቅናሽ!   \n\n~ፈኒ ኮትስ~",
                "ለሴት አያትህ በደንብ እስካላስረዳሃት ድረስ አወቅኩት ያልከዉ ነገር በትክክል አልገባህም  \n\n~ፈኒ ኮትስ~", "በህይወት በጣም ጠቃሚዉ ነገር በዚህ ሰአት እዚህ ቤት ዉስጥ ያለዉ ሰዉ ነዉ፡፡  \n\n~ቫን ዲስል~",
                "ጠላትህን መቼም አትጥላ ምክንያቱም ፍርድህን ያዛባብሃል! \n\n~ዘ ጎድ ፋዘር~", "ሌላ ሰዉ ያፈቀረችን ሴት በተቻለህ አቅም ባታፈቅር መልካም ነዉ..አለበለዚያ ከሞትክ በኋላ እንኳን ህመሙ አይለቅህም  \n\n~ኮት ኢንቦክስ~",
                "እባክህ እኔን እንዳትበላኝ!ሚስትና ልጆች አሉኝ…እነሱን ብላቸዉ!!  \n\n~ሆሜር ሲምፕሰን~", "ዶክተሬ የስድስት ወር እድሜ ብቻ እንደቀረኝ ነገረኝ  የሚገርመዉ ግን የሆስፒታል ወጪዬን መሸፈን እንዳቃተኝ ስነግረዉ ተጨማሪ ስድስት ወር ሰጠኝ፡፡  \n\n~ዋልተር ማታሁ~",
                "ባንክ ማለት የምትበደረዉን ብር እንደማትፈልገዉ ሲያረጋግጥ ብቻ የሚያበድርህ ተቋም ነዉ፡፡  \n\n~ቦብ ሆፕ~", "በአለም ላይ ባለብዙ ኮከብ የሆነ ሆቴል አገኘሁ፡፡ጣራዉ ክፍት ስለሆነ ኮከቦቹን በሙሉ ማየት ትችላለህ፡፡  \n\n~ያልታወቀ ሰዉ~",
                "ሁሉም ሰዉ ገነት መግባት ይፈልጋል ግን መሞት አይፈልግም፡፡  \n\n~ኩልንስማርት~", "አዲሱ መጥረጊያ ቤቱን በደንብ ሊያፀዳ ይችል ይሆናል..የድሮዉ መጥረጊያ ግን ጥጋጥጉን ሁሉ ያዉቃል  \n\n~አይሪሽ~",
                "ፀጉራቸዉን ብቻ በጣም ይወዱታል ምክንያቱም ሌላ የበለጠ ነገር ለመዉደድ አልታደሉም፡፡  \n\n~ጆን ግሪን~", "ስታለቅሺ አለቀስኩ…ስትስቂ ሳቅኩ…ከገደል ላይ ስትዘዪ የበለጠ አሳቅሺኝ!  \n\n~ኩልንስማርት~",
                "የኔ ምርጡ የወሊድ መቆጣጠሪያ ማብራቱን አብርቼ መተዉ ነዉ፡፡  \n\n~ጆዋን ሪቨርስ~", "ያረጀ ጭንቅላት እንዳረጀ ፈረስ ነዉ፤ስራ እንዲሰራልህ ከፈለግክ ሁል ጊዜ ማለማመድ አለብህ፡፡  \n\n~ጆን አዳምስ~",
                "ሴቶች ወንዶች ስለሚረሱት ነገር ሲጨነቁ ወንዶች ደግሞ ሴቶች ስለሚያስታዉሱት ነገር ይጨነቃሉ  \n\n*ፈኒ ኮትስ*", "ከ 20 አመት በኋላ ለምን አደረኩት ብለህ ሳይሆን እንዴት ሳላደርገዉ አሳለፍኩ ብለህ ትቆጫለህ   \n\n~ማርክ ትዌይን~",
                "ትላንት ምንም አልሰራሁም…ዛሬ ደግሞ ትላንት ያደረኩትን እየጨረስኩ ነዉ፡፡ \n\n~ስማይል~", "ትንሽ ዉሻ ሲጮህ አንበሳ ዞሮ እንኳን አያየዉም  \n\n~ፈኒ ኮትስ~",
                "አንተ የሆነ ነገር ታይና ‹ለምን› ብለህ ትጠይቃለህ…እኔ ደግሞ የሆነ ነገር አልምና ‹ለምን አይሆንም እላለሁ› \n\n~ጆርጅ በርናንድ ሾዉ~", "ይህ አለም የሌላ ፕላኔት ሲኦል ሊሆን ይችላል  \n\n~አልድዎስ ሄክስሌይ~",
                "የቅንጦት ኑሮን እጠላለሁ ምክንያቱ ምርጥ ልብስ፣ፈጣን ፈረስና የሚያማምሩ ሴቶች ሲኖሩኝ አላማዬንና ህልሜን ለመርሳት ጊዜ አይፈጅብኝም፡፡  \n\n~ጌንሂስ ካህን~",
                "የምፈልገዉን አደርጋለሁ፤ከተመቸህ አሪፍ..ካልተመቸህ ሂድና ወሬኛ ሰዉ የሚልህን ስማ፡፡  \n\n~አይስ ኪዩብ~", "የዉሸት ጓደኛና ጥላ ሁሌም ፀሃይ ሲወጣ ይመጣሉ፡፡  \n\n~ቤንጃሚን ፍራንክሊን~",
                "ህይወቴ አለቀለት ብለህ አትፍራ፤እንደገና እንደማይጀምር ካወክ ግን የዛኔ ፍራ!  \n\n~ግሬስ ሃንሰን~", "ሁል ግዜ ስትበደር ክፉ ነገር ከሚያስብ ሰዉ ተበደር፤ምክንያቱም ብሩን ትመልሳለህ ብሎ አይጠብቅም  \n\n~ኦስካር ዊልዴ~",
                "የልጆችህን የመጀመሪያ  ሁለት አመታት እንዲራመዱና እንዲያወሩ ታስተምራቸዋለህ፤ ከዛ የሚቀጥለዉን አስራ ስድስት አመት አርፈዉ እንዲቀመጡና አፋቸዉን እንዲዘጉ ደጋግመህ ትነግራቸዋለህ፤  \n\n~ያልታወቀ ሰዉ~",
                "የማታ ዜና ‹እንደምን አመሻችሁ› ብሎ የሚጀምርበት ቀጥሎ ደህና እንዳላመሸህ የሚዘከዘክበት  ሰአት ነዉ፡፡  \n\n~ያልታወቀ ሰዉ~", "ከሁለት ቀን በላይ ፌስቡክ ዉስጥ ካላያችሁኝ ቶሎ ብላችሁ ፖሊስ ጥሩ! \n\n~ኮትስሀብ~",
                "በስልሳ አምስት አመት ጡረታ መዉጣት ያናድዳል፤ስልሳ አምስት አመቴ ላይ ፊቴ ቡግር በቡግር ነበር፡፡  \n\n~ጆርጅ በርንስ~", "ለሰዉ ህዋ ላይ 300 ቢሊየን ኮከቦች አሉ ብለህ ብትነግረዉ ያምንሀል፤ ግን ቀለም የተቀባ ወንበር አሳይተኸዉ ቀለሙ እንዳልደረቀ ስትነግረዉ እርግጠኛ ለመሆን ወንበሩን መንካቱ አይቀርም፡፡  \n\n~ያልታወቀ ሰዉ~",
                "ሴት ልጅ የመላእክት ቅርጽ ፣የእባብ ልብና የሚያናድድ ሰዉ ጭንቅላት አላት  \n\n~ጀርመኖች~", "ህልምህን ተከተል ግን ወደቤትህ እንደገና የሚመልስህን መንገድ እወቅ  \n\n~ዚያድ አብድልኑር~", "የፌስቡክ ትርጉም በዲክሽነሪ…ፌስቡክ፡ ከ 2004 አ.ም ጀምሮ የሰዎችን ጊዜ የበላ አዞ  \n\n~ጂኒየስኮትስ~",
                "ዶናልድ ትረምፕ የፖለቲካ ልምድ ሳይኖረዉ ለፕሬዝዳንትነት ይወዳደራል…እኔ ግን ለ ጀማሪ የስራ መደብ ማስተርስ ዲግሪና አምስት አመት የስራ ልምድ ተጠየቅኩ  \n\n~ዴቢ ማጂክ~", "ጭንቅላትህ  ወንጀል ሲሰራ ተባባሪ ከመሆን ዉጪ  ልብህን መቼም አሸንፎት አያዉቅም   \n\n~ሚግኖን ማክላሊን~",
                "የትኛዋም ሴት እስካላለቀሰች ድረስ ዉሸቷን እየማለችልህ ነዉ! \n\n~ሳም ስሊክ~","ስሞት መቃብሬ ነፃ ዋይፋይ እንዲሰጥ አደርጋለሁ ከዛ ሰዎች ሁሌ ይጎበኙኛል ፡፡ \n\n~ዘወንደርስ~",
                "የማያዉቁኝ ሰዎች ዝምተኛ ሰዉ  እንደሆንኩ ያስባሉ ጓደኞቼ ተጫዋች ሰዉ እንደሆንኩ ያስባሉ..የልብ ጓደኞቼ ግን እብድ እንደሆንኩ ያዉቃሉ \n\n~ዘወንደርስ~",
                "ትምህርት ቤትና ህይወት ልዩነቱ ምንድነዉ? ትምህርት ቤት ትማርና ፈተና ትፈተናለህ  ህይወት ደግሞ ትፈተንና ከዛ ትማርበታለህ \n\n~ቶም ቦሬት~",
                "ሰዎች ያለፍቅር  መኖር አይቻልም ያላሉ እኔ ግን ኦክስጅን ከሁሉም በላይ አስፈላጊ ነዉ እላለሁ  \n\n~ዘወንደርስ~" ,
                "ህይወት ምንም እጅ የላትም ነገር ግን አንዳንዴ በጥፊ ትማታለች  \n\n~ዘወንደርስ~" ,
                "ብርቅዬ እንስሳ ብርቅዬ ተክል ሲበላ ብታይ ምን ታደርጋለህ?  \n\n~ጆርጅ ካርሊን~" ,
                "የሚደብሩህን ሰዎች መለየት ቀላል ነዉ፡፡ጓደኞችህን መለየት ግን ከባዱ ፈተና ይሆንብሃል፡፡  \n\n~ማጊ ስሚዝ~" ,
                "ሁሉም ልብወለድ እስካልጨረስከዉ ድረስ ሚስጥር  እንደሆነ ይኖራል፡፡  \n\n~ሜጋን አምራም~" ,
                "ከዶክተርህ ጋር አትከራከር፡፡እሱ ያንተን የዉስጥ ኢንፎርሜሽን ይዟል፡፡  \n\n~ቦብ ኤሊየት~" ,
                "ለአባቴ መቶ ዶላር ሰጠሁትና ዛሬ  ህይወትህን ቀለል አርግበት አልኩት..ከዛ ሄዶ ለእናቴ ስጦታ ገዛላት \n\n~ሪታ ሩዉድነር~"+ "\n")

    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen_slide)

        val statusBarSetting : Window = this.window
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){

            statusBarSetting.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            statusBarSetting.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            statusBarSetting.statusBarColor = ContextCompat.getColor(this,android.R.color.black)
        }

        mPager = findViewById(R.id.pager)
        myButton = findViewById(R.id.new_but)
        backgroundLayout = findViewById (R.id.backgroundImage)
        mAdView = findViewById(R.id.adView)

        mPagerAdapter = ScreenSlidePagerAdapter(supportFragmentManager)
        mPager.adapter = mPagerAdapter

        Glide.with(this).load(R.drawable.women).into(backgroundLayout)

        val adRequest = AdRequest.Builder().build()
        mAdView.loadAd(adRequest)


        myButton.setOnClickListener {

            val prefs = getPreferences(Context.MODE_PRIVATE)
            var clickCount = prefs.getInt(ContentOne.KEY_CLICK_COUNT,0)
            clickCount ++

            val sharingIntent = Intent(Intent.ACTION_SEND)
            sharingIntent.type = "text/plain"
            sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "ሳቅ..")
            sharingIntent.putExtra(Intent.EXTRA_TEXT, quoteContents[mPager.currentItem])
            startActivity(Intent.createChooser(sharingIntent, "ሼር ያድርጉ!"))
            prefs.edit().putInt(ContentOne.KEY_CLICK_COUNT,clickCount).apply()


        }
    }

    inner class ScreenSlidePagerAdapter(fm: FragmentManager) : FragmentStatePagerAdapter(fm) {


        private val mCount = quoteContents.size

        override fun getItem(position: Int): Fragment {

            return  ViewPagerAdapter.newInstance(quoteContents[position % quoteContents.size])
        }

        override fun getCount(): Int = mCount

    }

}
