package com.afc.qewachquotes

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import android.support.v4.content.ContextCompat
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.bumptech.glide.Glide


class ContentOne : FragmentActivity() {

    private lateinit var mAdView: AdView
    private lateinit  var mPager: ViewPager
    private lateinit var mPagerAdapter: PagerAdapter
    private var backgroundLayout: ImageView ?= null
    private lateinit var myButton : Button

    companion object {

        const val  KEY_CLICK_COUNT = "1"
        private val quoteContents = arrayOf(
                "ከስኬት በኋላ ያለዉ ትልቁ ፈተና ስለስኬትህ አለማዉራት ነዉ\n\n~ክሪስ ጃሚ~",
                "በማሸነፍና በመሸነፍ መካከል ያለዉ ልዩነት ተስፋ አለመቁረጥ ነዉ፡፡" + "\n" + "\n" + "~ዋልት ዲስኒ~",
                "ሁሉም ሰዉ በመጨረሻ ‹እንደዚህ አይነት ሰዉማ በጭራሽ አልሆንም› ብሎ የተፀየፈበትን ማንነት ይሆናል " + "\n" + "\n" + "~ሳድ ኮትስ~",
                "ህይወትህን ዛሬ ቀይር..ነገ በሚመጣዉ ነገር ቁማር አትጫወት…ያለምንም መዘግየት አሁኑኑ ተንቀሳቀስ! " + "\n" + "\n" + "~ሲሞን ዲ ቢቮዉር~",
                "ጥያቄዉ ማን ይፈቅድልኛል አይደለም፡፡ ጥያቄዉ ማን ያስቆመኛል ነዉ\n\n~አይን ራንድ~",
                "አየህ አይደል!እግዚአብሄር የሚረዳቸዉ ሰዎች ጠንክረዉ የሚሰሩትን ነዉ\n\n~አብዱል ካላም~",
                "የምትሰራዉ ስራ አፍ አዉጥቶ መናገር ሲጀምር እባክህን አታቋርጠዉ\n\n~ሄነሪ ኬይሰን~",
                "አንድ ሰአት ያለምንም ስራ ለማባከን ሃሞቱ ያለዉ ሰዉ የህይወት ዋጋ አልገባዉም\n\n~ቻርልስ ዳርዊን~",
                "እድልና መልካም አጋጣሚ ያልደገፈዉ የህይወቴ አጋጣሚ ቢኖር ብዙ ሰዎች የጀመሩትን አቋረጡ እኔ ደግሞ ጉዞዬን ቀጠልኩ"  + "\n" + "\n" +"~ሃሪሰን ፎርድሰዉ~",
                "የእድል መስኮት በራሱ አይከፈትም" + "\n" + "\n" + "~ዴቭ ዊንባም~",
                "ከባድ ሊሆን ግድ ነዉ…ቀላል ቢሆንማ ማንም ሰዉ ያደርገዉ ነበር፡፡" + "\n" + "\n" +"~ጂሚ ዱጋን~",
                "እግሮችህን መሬት ላይ አይኖችህን ደግሞ ክዋክብቶቹ ላይ አድርጋቸዉ፡፡"+ "\n" + "\n" + "~ቴዎድር ሩዝቬልት~",
                "ከስኬት በኋላ ያለዉ ትልቁ ፈተና ስለስኬትህ አለማዉራት ነዉ፡፡" + "\n" + "\n" + "~ክሪስ ጃሚ~",
                "ድካም ከሌለ ለዉጥ የለም" + "\n" + "\n" + "~ፍሬድሪክ ዳግላስ~",
                "ህይወት የምትፈልገዉን ነገር ልትሰጥህ ግዴታ የለባትም"+ "\n" + "\n" +"~ማርጋሬት ሚቼል~",
                "ሰዉ አባቱ የነገረዉ ነገር ሁሉ እዉነት መሆኑን በተረዳበት እድሜ ላይ እዉነት እንደሌለ የሚያስብ ልጅ ይኖረዋል፡፡" + "\n" + "\n" + "~ቻርልስ ዋድስዎርዝ~",
                "አንድ ሰዉ ተሳካለት የምለዉ አንዴ በወጣዉ ከፍታ ሳይሆን ህይወቱ ሲዘቅጥ እንደገና ተስፈንጥሮ በወጣዉ ርዝመት ልክ ነዉ" + "\n" + "\n" + "~ጀኔራል ጆርጅ ኤስ ፓቶን~",
                "ስኬታማነት ምንም ሚስጥር የለዉም፤ስኬት የዝግጁነት፣ጠንክሮ የመስራትና ከስህተቶችህ ትምህርት የምትወስድበት ዉጤት ነዉ" + "\n" + "\n" + "~ኮሊን ፓዉል~",
                "በቢዝነስ ላይ የተመሰረተ ጓደኝነት በጓደኝነት ላይ ከተመሰረተ ቢዝነስ ይሻላል" + "\n" + "\n" + "~ጆን ዲ ሮክፌለር~",
                "ዉድቀት ማለት አንድን ነገር እንደገና መጀመር ነዉ ግን አሁን በብዙ ብልሀት መጓዝ ያስፈልጋል፡፡" + "\n" + "\n" + "~ሄነሪ ፎርድ~",
                "ሰዉ ስህተቱን ሊያምን ከስህተቶቹ ሊማርና ስህተቶቹን ለማስተካከል ቆራጥ ሊሆን ይገባዋል፡፡" + "\n" + "\n" + "~ጆን ሲ.ማክስዌል~",
                "ጨለማዉን እወደዋለሁ፤ባይመሽ ኖሮ ኮከቦቹን መቼም አላያቸዉም ነበር፡፡ " + "\n" + "\n" + "~ስቴፈኒ ሜየር~",
                "የስኬት ቁልፉ ምን እንደሆነ አላዉቅም የዉድቀት ቁልፉ ግን ሁሉንም ሰዉ ለማስደሰት መሞከር ነዉ፡፡" + "\n" + "\n" + "~ቢል ኮዝቢ~",
                "ዉድቀት የመጨረሻ አይደለም ለመለመጥ አለመቻል ግን የሰዉ መጨረሻ ሊሆን ይችላል  " + "\n" + "\n" + "~ጆን ዉድን~",
                "ስኬትን ለማግኘት እሰራለሁ እንጂ አልሜዉ አላዉቅም  " + "\n" + "\n" + "~ኢስቴ ላዉደር~",
                "ተስፋ መቁረጥ የዉድቀት ብቸኛዉ መንገድ ነዉ" + "\n" + "\n" + "~ጌና ሾዉአልተር~",
                "ሊሆን በሚችለዉ አደጋ ላይ ካተኮርክ ሃሳብህ ዉስጥ ይባዙና ፓራላይዝ ያረጉሃል..ይልቅስ ማድረግ ስላለብህ ነገር ብቻ አስብ " + "\n" + "\n" + "~ቤሪ ኢስለር~",
                "ለማድረግ እየሞከርኩ ያለሁት የተለመደዉን አይነት አሰራር አይደለም…የኔ ምርጫ ፈፅሞ ባልተሰራበት መንገድ መስራት ነዉ፡፡" + "\n" + "\n" + "~ሚካኤል ትሬኖር~",
                "ስኬታማ ሰዉ ማለት ሌሎች ሰዎች የወረወሩበትን ድንጋይ አንስቶ ፅኑ መሰረት የሚያደርግ ሰዉ ነዉ፡፡ " + "\n" + "\n" + "~ዴቪድ ብሪንክሌይ~",
                "በዚህ ህይወት የሚያስፈልግህ ነገር ቢኖር የሰዉን ወሬ ንቆ መተዉና በራስ መተማመን ነዉ፤ከዛማ ያለምንም ጥርጥር ስኬት ይከተልሃል" + "\n" + "\n" + "~ማርክ ትዌይን~",
                "እዉነትን የሚናገሩ ተከታዮችና ተከታዩቻቸዉን የሚያዳምጡ መሪዎች ጠንካራና የማይሸነፍ ማንነትን ይፈጥራሉ" + "\n" + "\n" + "~ዋረን ቤኒስ~",
                "የስኬት አንዱ ገፅታ ተስፋ ሳይቆርጡ ከዉድቀት ወደ ዉድቀት መራመድ ነዉ፡፡" + "\n" + "\n" + "~ዊንስተን ቸርችል~", "አስር ሺህ አይነት የማያዋጡ መንገዶችን ሞከርኩ እንጂ አልወደቅኩም" + "\n" + "\n" + "~ቶማስ አልቫ ኤዲሰን~",
                "የሰዉ ልጅ ትክክለኛዉ መመዘኛ መልካም ነገር አድርጎለት የማያዉቀዉን ሰዉ የሚይዝበት መንገድ ነዉ" + "\n" + "\n" + "~ሳሙኤል ጆንሰን~",
                "የስኬት ግብህ ለሌላ ጊዜ ተዘዋወረ እንጂ አልወደቅክም" + "\n" + "\n" + "~ዴይሊ ኮትስ~",
                "አንዳንዴ ‹ደህና ነኝ› ስል የሆነ ሰዉ አተኩሮ አይቶኝ ‹ባክህ እዉነቱን ተናገር› እንዲለኝ እፈልጋለሁ፡፡" + "\n" + "\n" + "~ሳድ ኮትስ~",
                "የስኬት መሰረት ከሆኑት ዉስጥ ያሰብከዉን ያለምንም ማወላወል መፈፀም ነዉ፡፡" + "\n" + "\n" + "~ፓብሎ ፒካሶ~",
                "በልብህ መርሳት የሌለብህ ነገር ቢኖር ስኬትም ይሁን ዉድቀት ለዘላለም የሚቆዩ አይደሉም" + "\n" + "\n" + "~ሮገር ዋርድ~",
                "ስኬት 99 ፐርሰንቱ ዉድቀት ነዉ" + "\n" + "\n" + "~ሶሂቺሮ ሆንዳ~", "ጠላቶችህ ዉድቀትህን ለሰዉ ያዉጃሉ ስኬትህን ግን ይንሾካሾኩታል  " + "\n" + "\n" + "~ቲፕስ 21~",
                "ስኬት ለብቻዉ ያቅፍሃል ዉድቀት ግን በህዝብ ፊት ያጨበጭብልሃል  " + "\n" + "\n" + "~ፖሊቮር~", "ዉድቀት ለስኬት የምትከፍልለት የቤት ኪራይ ነዉ፡፡ " + "\n" + "\n" + "~ዋልተር ብሩኔል~",
                "ስኬት ወደአእምሮህ፤ ዉድቀት ደግሞ ወደልብህ እንዲገቡ አትፍቀድላቸዉ፡፡" + "\n" + "\n" + "~ዊል ስሚዝ~", "እንድወደድ ሳይሆን እንድከበር እፈልጋለሁ፡፡" + "\n" + "\n" + "~ጃክ ማ~",
                "የዉድቀት መርከብ በይቅርታ ባህር ላይ ትንሳፈፋለች" + "\n" + "\n" + "~ኢሜጅስ በዲ~", "ችግሮች እንደሚኖሩ እወቅ..ከዛ ችግሮችህን ቁርስህ አድርጋቸዉ  " + "\n" + "\n" + "~አልፍሬድ ኤ ሞንታፔርት~",
                "ሰአትህን አትመልከት ይልቅስ ጊዜ የሚሰራዉን ስራ…ጉዞህን ቀጥል! " + "\n" + "\n" + "~ሳም ሌቨንሰን~", "ስኬት ይማራል ዉድቀት ግን ያማርራል!" + "\n" + "\n" + "~ዶርቶካርኔይ~",
                "ጨረቃ ላይ አልም..ጨረቃን ብትስት እንኳ ኮከቦቹን ታገኛለህ  " + "\n" + "\n" + "~ደብሊዉ ክሌመንት ስቶን~",
                "የስኬት መንገድ አንድ ብቻ ነዉ፤እሱም የህይወትህን አቅጣጫ በራስህ መምራት!" + "\n" + "\n" + "~ክርስቶፈር ሞርሌ~", "ችግሮችህን አትፋለማቸዉ ነገር ግን ወስንባቸዉ! " + "\n" + "\n" + "~ጆርጅ ቺ ማርሻል~",
                "‹ጥሩ ሰርተሃል› ከ ‹ጥሩ ተናግረሃል› ይሻላል  " + "\n" + "\n" + "~ቤንጃሚን ፍራንክሊን~", "ስኬት በተቀረፅክበት ማንነት ልክ የምታገኘዉ ነገር ነዉ " + "\n" + "\n" + "~ጂም ሮን~",
                "የምናስበዉን ነገር እንሆናለን " + "\n" + "\n" + "~አርል ናይትንጌል~", "ኮርጀህ ከሚሳካልህ በራስህ ሰርተህ ብትወድቅ ይሻላል " + "\n" + "\n" + "~ኸርማን ሜልቪሌ~",
                "የስኬት ሚስጥሩ ማንም ሰዉ ያላወቀዉን ነገር መገንዘብ ነዉ" + "\n" + "\n" + "~አርስቶትል~", "ትግስት ማጣት ስኬትን አዞት አያዉቅም " + "\n" + "\n" + "~ኤድዊን ቻፕሊን~",
                "ወደፊት የሚያስኬድ መንገድ ይሁን እንጂ የትም እሄዳለሁ" + "\n" + "\n" + "~ዴቪድ ሊቪንግስተን~", "ቁስሎችህን ወደ ጥበብ ቀይራቸዉ   " + "\n" + "\n" + "~ኦፕራ ዊንፍሬይ~",
                "የስኬትን መክፈቻ ቁልፍ ማግኘት ካቃተህ መዝጊያዉን አንሳ፡፡" + "\n" + "\n" + "~ያልታወቀ ሰዉ~", "ዉድቀት የስኬት ተቃራኒ አይደለም፡ዉድቀት የስኬት አካል ነዉ፡፡" + "\n" + "\n" + "~ዴይሊ ኮትስ~",
                "ህይወት ተፅእኖ የማምጣት ጉዞ እንጂ ገቢ የማስገባት ሩጫ አይደለም" + "\n" + "\n" + "~ኬቨን ክሩስ~",
                "ደስታ የስኬት ቁልፍ እንጂ ስኬት የደስታ ቁልፍ  አይደለም፡፡ የምትሰራዉን ነገር  ከወደድከዉ ስኬታማ ትሆናለህ፡፡"  + "\n" + "\n" +"~ሄርማን ኬይን~",
                "በዉድቀትህ አትደንግጥ ነገር ግን ትምህርት ወስደህ እንደገና ጀምር"  + "\n" + "\n"  + " ~ሪቻርድ ብራንሰን~",
                "ስኬት ቀላል ነዉ፡፡ትክክል የሆነዉን በትክክለኛዉ መንገድና ሰአት ፈፅም፡፡" + "\n" + "\n" + "~አርኖልድ  ግላስጎዉ~",
                "ዉድቀትን ስታዉቅ ማሸነፍህ በጣም ይጣፍጥሃል " + "\n" + "\n" + "~ማልኮልም ፎርብስ~",
                "ተግባር የሁሉም ስኬት መሰረት ነዉ" + "\n" + "\n" + " ~ፓብሎ ፒካሶ~",
                "ህይወት ራስህን ስለማግኘት አይደለም፡፡ ህይወት ራስህን ስለመቅረፅ ነዉ" + "\n" + "\n" + "~ጆርጅ በርናንድ ሾዉ~",
                "ብዙ ያለዉ ሳይሆን ብዙ የሚሰጥ ሀብታም ነዉ" + "\n" + "\n" + "~ኤሪክ ፍሮም~",
                "በህይወትህ ስኬት ከፈለክ ሁለት ነገሮችን ያዝ፡፡ወሬ ቸል ማለትና በራስ መተማመን !" + "\n" + "\n" + "~ማርክ ትዌይን~",
                "ከማንም አትጠብቅ፡፡ ጊዜዉ ምንም አሪፍ ቢሆን ላይደረግልህ ይችላል፡፡" + "\n" + "\n" + "~ናፖሊዬን ሂል~",
                "ካለህበት ቦታ ሆነህ ጀምር፡፡ ጊዜህን ተጠቀም፣የምትችለዉን አድርግ" + "\n" + "\n" + "~አርተር አሽ~")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen_slide)

        val statusBarSetting : Window = this.window
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){

            statusBarSetting.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            statusBarSetting.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            statusBarSetting.statusBarColor = ContextCompat.getColor(this,android.R.color.black)

        }


        mPager = findViewById(R.id.pager)
        myButton = findViewById(R.id.new_but)
        backgroundLayout = findViewById (R.id.backgroundImage)
        mAdView = findViewById(R.id.adView)

        mPagerAdapter = ScreenSlidePagerAdapter(supportFragmentManager)
        mPager.adapter = mPagerAdapter

        Glide.with(this).load(R.drawable.success).into(backgroundLayout)
        val adRequest = AdRequest.Builder().build()

        mAdView.loadAd(adRequest)
        myButton.setOnClickListener {

            val prefs = getPreferences(Context.MODE_PRIVATE)
            var clickCount = prefs.getInt(KEY_CLICK_COUNT,0)
            clickCount ++

            val sharingIntent = Intent(Intent.ACTION_SEND)
            sharingIntent.type = "text/plain"
            sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "ስኬትና ዉድቀት")
            sharingIntent.putExtra(Intent.EXTRA_TEXT, quoteContents[mPager.currentItem])
            startActivity(Intent.createChooser(sharingIntent, "ሼር ያድርጉ!"))
            prefs.edit().putInt(KEY_CLICK_COUNT,clickCount).apply()


        }
    }

    inner class ScreenSlidePagerAdapter(fm: FragmentManager) : FragmentStatePagerAdapter(fm) {

        private val mCount = quoteContents.size

        override fun getItem(position: Int): Fragment {

            return  ViewPagerAdapter.newInstance(quoteContents[position % quoteContents.size])
        }

        override fun getCount(): Int = mCount

    }


}
