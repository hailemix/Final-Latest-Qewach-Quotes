package com.afc.qewachquotes

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import android.support.v4.content.ContextCompat
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.bumptech.glide.Glide


class ContentSeven: FragmentActivity() {

    private lateinit var mAdView: AdView
    private lateinit  var mPager: ViewPager
    private lateinit var mPagerAdapter: PagerAdapter
    private var backgroundLayout: ImageView ?= null
    private lateinit var myButton : Button




    companion object {

        const val  KEY_CLICK_COUNT = "1"
        private val quoteContents = arrayOf(
                "እዉነት በዝምታ ሲተካ ዝምታዉ ዉሸት ይሆናል\n\n~የቨትሹንኮ~",
                "ስለራስህ እውነቱን ካልተናግረክ ስለሌላ ሰው ማንነት ልትናገር አትችልም፡፡\n\n~ቨርጂኒያ ዉልፍ~",
                "ህልም ያላቸው ታሪኮች  ህልም የሌላቸውን ሰዎች  ያናድዳሉ፡፡\n\n~ቴሪ  ፕራሽት~",
                "ሰዉነታችን ላይ የማይታዩ  ግን ከምንም በላይ የሚደሙና የሚያሙ ህመሞች አሉ\n\n~ላዉረል ሃሚልተን~",
                "ሁለቱ ከባባድ ጀግኖች ትእግስትና ጊዜ ናቸዉ\n\n~ሊዮ ቶልይስቶይ~",
                "ማንም ቢሆን የእንባህን ያህል ዋጋ ሊኖረዉ አይችልም፡፡ ዋጋ ያለዉ ከሆነ ደግሞ ሊያስለቅስህ አይችልም፡፡\n\n~ያልታወቀ ሰዉ~",
                "ፍርሃት በሩን አንኳኳ..እምነት መልስ ሊሰጥ ሲመጣ በቦታዉ ማንም አልነበረም ፡፡\n\n~ያልታወቀ ሰዉ~",
                "ኩረጃ እራስን ማጥፋት ነዉ\n\n~ራልፍ ዋልዶ ኤመርሰን~",
                "ሰዉ ለስራ ብሎ ቤተሰቦቹን መተዉ ፈፅሞ የለበትም\n\n~ዋልት ዲስኒ~",
                "እኛ ማለት የምናምነዉን አይነት ሰዎች ነን\n\n~ሲኤስ ሊዊስ~",
                "ቅጣት መቅጣት ፍትህ ለማያዉቀዉ ሰዉ ፍትህ እንደመስጠት ነዉ\n\n~ሴይንት ኦገስቲን~",
                "ከባባድ ጊዜዎች አይቆዩም ከባባድ ሰዎች ግን ይቆያሉ\n\n~ሮበርት ሹለር~",
                "ደስታ ከሰዎች  ጋር ስትካፈለዉ ብቻ እዉነተኛ ደስታ ይሆናል፡፡\n\n~ጆን ክራኮቨር~",
                "እራሱን ለመሆን የማይፈልግ ፍጡር የሰዉ ልጅ ብቻ ነዉ፡፡\n\n~አልበርት ካመስ~",
                "ተስፋ መቁረጥ የህይወትህ የመጨረሻዉ አማራጭ መሆን አለበት  \n\n~ጣሊያናዊያን~" ,
                "ህይወት የደስታና የእንባ ቅንብር ናት፡፡ጠንካራና እምነት ያለዉ ሰዉ ሁን! \n\n~ካሬና ካፑር~" ,
                "ደረጃዎቹን ሁሉ ማየት ቢያቅትህም እምነት የመጀመሪያዉ እርምጃ ነዉ \n\n~ማርቲን ሉተርኪንግ~" ,
                "በትንሹ ነገር እምነት ይኑርህ ምክንያቱም ጥንካሬህ በነሱ ላይ ይደገፋል  \n\n~ማዘር ቴሬዛ~" ,
                "እግዚአብሄር የማትችለዉን ነገር አይሰጥህም ስለዚህ አትጨናነቅ \n\n~ኬሊ ክላርሰን~" ,
                "አንዳንዴ ህይወት በድንጋይ ራስህን ትመታሃለች…ግን ተስፋ አትቁረጥ \n\n~ስቲቭ ጆብስ~" ,
                "እምነት ሁሉም ነገር እንዲቻል ያደርጋል ፍቅር ደግሞ ሁሉን ነገር ያቀለዋል \n\n~ድዋይት ሙዲ~" ,
                "ከባድ ቀናት ብዙ አይቆይም ጠንካራ ሰዉ ግን ብዙ ይቆያል \n\n~ሊዲያ ስዌት~" ,
                "የጠንካራነት ስሜት ሲሰማኝ አእምሮዬ ወደላይ ከፍ ይላል  \n\n~ፒንክ~" ,
                "ጠንካራ ሁን! ቀና በል ..ድምፅህን አሰማ! \n\n~ሻዉን ጆንሰን~" ,
                "ህይወት ከባድ ነዉ፡፡የኔ ዉድ አንቺም ግን በጣም ሃይለኛ ነሽ \n\n~ስቴፋኑ በርነል~",
                "ሰላምን ከነፃነት መለየት አትችልም ምክንያቱም ማንም ሰዉ ነፃነት ሳይኖረዉ ሰላም ሊሆን አይችልም፡፡ \n\n~ማልኮልም ኤክስ~",
                "ተስፋን ከመረጥክ ሁሉም ነገር ይቻላል፡፡ \n\n~ክርስቶፈር ሪቭ~",
                "ሀብታም ግን ነፃነት የናፈቀዉ ሀገር ከምኖር ድሃና ነፃ ሀገርን እመርጣለሁ \n\n~ዉድሮዉ ዊልሰን~",
                "ብዙ ሰዎች እድልን የሚያጡት ተሸፋፍኖ የተለመደ ስራ ስለሚመስል ነዉ \n\n~ቶማስ ኤዲሰን~",
                "ሙሉ ጥበቃ ተደርጎልህ መኖር ከፈለክ እስር ቤት ግባ፡፡ እዛ ይመግቡሃል፣ያለብሱሃል፣ህክምና በነፃ ታገኛለህ ወዘተ..አንድ የምታጣዉ ነገር ቢኖር ነፃነትህን ነዉ፡፡\n\n~ድዋይት ኢስንሆቨር~",
                "ተስፋ የቆረጠ ሰዉ ወይም ተስፈኛ ሆነህ ልትኖር ትችላለህ…ምንም ይሁን ምን ምርጫዉ ያለዉ አንተዉ ጋር ነዉ፡፡ \n\n~ዋይኒ ዴየር~",
                "ታላቅ መሆን የሚወለደዉ ከራስ ወዳድነት ሳይሆን ከከባድ መስዋእትነት በኋላ ነዉ፡፡\n\n~ናፖሊዩን ሂል~",
                "የሰዉን ፀባይ ለማወቅ ከፈለክ ስልጣን ስጠዉ፡፡\n\n~አብርሃም ሊንከን~",
                "እዉነት ዉስጥ ሆኖ መንቃት ዉሸት ዉስጥ ሆኖ ከመኖር በጣም ይበልጣል \n\n~ኢድሪስ ኢልባ~",
                "እየታየ ያለዉን ነገር ማጥፋት ትችላለህ ነገር ግን በማጥፋትህ የሚመጣብህን መዘዝ ማቆም አትችልም! \n\n~አይን ራንግ~",
                "በመጨረሻ የምናስታዉሰዉ ነገር የጠላቶቻችንን ንግግር ሳይሆን የጓደኞቻችንን ዝምታ ነዉ \n\n~ማርቲን ሉተር ኪንግ~",
                "በኔና ባበደ ሰዉ መካከል ያለዉ ልዩነት አለማበዴ ነዉ፡፡\n\n~ሳልቫዶር ዳሊ~",
                "ድፍረት ማለት ፍርሃትን መቋቋምና በፍርሃት ላይ መንገስ ነዉ እንጂ ፍርሃትን ማስቀረት አይደለም  \n\n~ማርክ ትዌይን~",
                "የእግዚአብሄርን ሃሳብ ማወቅ እፈልጋለሁ…ሌላዉ ሁሉ ቀጥሎ የሚመጣ ነዉ፡፡ \n\n~አልበርት እንስታይን~",
                "በህይወት ከባዱ ስህተት ያለማቋረጥ ልሳሳት እችላለሁ ብሎ ሁሌ መፍራት ነዉ \n\n~ኤልበርት ሁበርድ~",
                "በመጨረሻ የምታስተዉለዉ ነገር ቢኖር በኖርክበት እድሜ ልክ ያሳለፍከዉ ህይወት እንጂ በህይወትህ ያሳለፍከዉ የእድሜ ቁጥር ዋጋ እንዳልነበረዉ ነዉ \n\n~አልበርት እንስታይን~",
                "ሩህሩህ ሰዉ መሆን ማለት መስማት የተሳነዉ የሚያዳምጠዉና ማየት የተሳነዉ የሚያየዉ መግባቢያ ቋንቋ ነዉ  \n\n~ማርክ ትዌይን~",
                "እራሴን ሳልሆን በሰዉ ከምወደድ እራሴን ሆኜ በሰዉ ብጠላ ይሻለኛል \n\n ኩርት ኮቤይን",
                "ትክክለኛዉ ሃብት የብርና የወርቅ ብዛት ሳይሆን ጤንነት ነዉ  \n\n~ማህተመ ጋንዲ~",
                "ዘላለም እንደምትኖር አድርገህ አልም..ዛሬ እንደምትሞት አድርገህ ኑር! \n\n~ጄምስ ዲን~",
                "ልታሰምርበት የሚገባዉ የጓደኞችህ ጥራት እንጂ የጓደኞችህ ብዛት አይደለም፡፡\n\n~ትሩዝ ኮትስ~",
                "እዉነትን ከተናገርክ ምንም ነገር እንድታስታዉስ አይጠበቅብህም \n\n~ማርክ ትዌይን~",
                "በጣም ጎበዝ ስለሆንኩ አይደለም ነገር ግን ከችግሮቼ ጋር ብዙ ጊዜ ስለማሳልፍ ነዉ፡፡ \n\n~አልበርት እንስታይን~",
                "በራስ መተማመን ከሌለህ በህይወት ሩጫ ዉስጥ ሁለቴ ትሸነፋለህ  \n\n~ማርከስ ጋርቬይ~",
                "ዝለል..! ከዛ ክንፎችህን እንዴት መዘርጋት እንደሚኖርብህ በጊዜዉ ታዉቃለህ \n\n~ረይ ብራድበሪ~",
                "ጀግንነት ማለት እስከሞት ድረስ እየፈራህ ስራህን በትክክል መፈፀም ነዉ \n\n~ኦማር ብሬድሊ~",
                "ድምፅህ ቢቆራረጥም ሃሳብህን ተናገረዉ!\n\n~ማጊ ኩኸን~",
                "በትክክል የተጀመረ ስራ ግማሹ አልቋል \n\n~አርስቶትል~",
                "የተጨበጨበለት ነገር በድንገት አይከሰትም! \n\n~ኢፒክቴተስ~",
                "ጀግና ዘላለም ላይኖር ይችላል የሚርበተበት ሰዉ ግን አንድ ቀን እንኳ አይኖርም \n\n~ኤሽሊ ኤል~",
                "ብዙ ከሚያቆይ ሃሳብ ቶሎ መንቃት አለብን \n\n~ፖዉል ቫለሪ~",
                "ነገሮችን መርሳትና መደሰት አትርሳ! \n\n~ጆን ማክሊዩድ~",
                "ተስፋና የገሃዱ አለም ሁሌም በተቃራኒዉ ይገኛሉ \n\n~ጆዲ ፒኮልት~",
                "በጨለማ ዉስጥ ስትሆን ብቻ ኮከቦቹ ይታዩሃል \n\n~ማርቲን ሉተርኪንግ~",
                "ህይወትን በማጥፋት ሰላምን አታገኝም \n\n~ቨርጂኒያ ዉልፍ~",
                "ነፍስህን አጉድለህ የአለምን ሃብት አትሰብስብ፤ጥበብ ከብርና ከወርቅ ትልቃለች! \n\n~ቦብ ማርሌይ~",
                "ሰዎች ለምንድነዉ ቁጭ ብለዉ መፅሃፍ በማንበብ እርስ በርሳቸዉ መልካም ማድረግን የማይማሩት? \n\n~ዴቪድ ባልዳቺ~",
                "ህይወት እኛ የጠበቅነዉን ነገር የመስጠት ግዴታ የለባትም \n\n~ማርጋሬት ሚቼል~",
                "ምንም የማይጠብቅ ሰዉ የተባረከ ነዉ ምክንያቱም ልቡ አይጎዳም \n\n~አሌክሳንደር ፖፕ~",
                "ጥፋት በሆነበት ዘመን ላይ ከሆንክ የሆነ ነገር ፍጠር \n\n~ማክሲን ሆንግ~",
                "ተስፋ ምርጥ ቁርስና አስቀያሚ መክሰስ ነዉ  \n\n~ፍራንሲስ ቤከን~",
                "በህይወት መኖር እንዴት ደስ ይላል! \n\n~ሄነሪ ሰተን~",
                "ከፍላጎቶችህ ነፃ መዉጣት የዉስጥ ሰላም ይሰጥሃል \n\n~ላኦ ሴ~",
                "ከዛሬ ቀን በላይ ዉድ ነገር የለም \n\n~ጎቴ~",
                "ፀጥ ባልክ ቁጥር ብዙ ትሰማለህ \n\n~ስዋሚ ራማ~",
                "የሚበቃዉን ያህል እንዳለዉ የሚያዉቅ ሰዉ ሀብታም ነዉ\n\n~ሄንሪ ዴቪድ~",
                "አትቸኩል፤አትጨነቅ፤የቻልከዉን ያህል ስራና እረፍ!\n\n~ቴድ በርግናይን~",
                "ሰላም ሁልጊዜም ዉብ ነዉ \n\n~ዋልት ዊትማን~",
                "ህይወቴ በተቀበሩ ተስፋዎች የተሞላ መቃብር ነዉ \n\n~ሞንትጎመሪ",
                "የሰዉ ልጅ የመጀመሪያዉ ሃላፊነት ስለራሱ ማሰቡ ነዉ  \n\n~ጆሴ ማርቲ~")





    }

override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_screen_slide)

    val statusBarSetting : Window = this.window
    if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){

        statusBarSetting.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        statusBarSetting.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        statusBarSetting.statusBarColor = ContextCompat.getColor(this,android.R.color.black)

    }


    mPager = findViewById(R.id.pager)
    myButton = findViewById(R.id.new_but)
    backgroundLayout = findViewById (R.id.backgroundImage)
    mAdView = findViewById(R.id.adView)

    mPagerAdapter = ScreenSlidePagerAdapter(supportFragmentManager)
    mPager.adapter = mPagerAdapter


    Glide.with(this).load(R.drawable.lead).into(backgroundLayout)
    val adRequest = AdRequest.Builder().build()
    mAdView.loadAd(adRequest)


    myButton.setOnClickListener {

        val prefs = getPreferences(Context.MODE_PRIVATE)
        var clickCount = prefs.getInt(ContentOne.KEY_CLICK_COUNT,0)
        clickCount ++

        val sharingIntent = Intent(Intent.ACTION_SEND)
        sharingIntent.type = "text/plain"
        sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "እዉነት..")
        sharingIntent.putExtra(Intent.EXTRA_TEXT,quoteContents[mPager.currentItem])
        startActivity(Intent.createChooser(sharingIntent, "ሼር ያድርጉ!"))
        prefs.edit().putInt(ContentOne.KEY_CLICK_COUNT,clickCount).apply()


    }
}

    inner class ScreenSlidePagerAdapter(fm: FragmentManager) : FragmentStatePagerAdapter(fm) {


        private val mCount = quoteContents.size

        override fun getItem(position: Int): Fragment {

            return  ViewPagerAdapter.newInstance(quoteContents[position % quoteContents.size])
        }

        override fun getCount(): Int = mCount

    }

}
