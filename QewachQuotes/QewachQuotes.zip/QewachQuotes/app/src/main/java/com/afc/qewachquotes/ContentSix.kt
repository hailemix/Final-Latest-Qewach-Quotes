package com.afc.qewachquotes

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import android.support.v4.content.ContextCompat
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.bumptech.glide.Glide


class ContentSix: FragmentActivity() {

    private lateinit var mAdView: AdView
    private lateinit  var mPager: ViewPager
    private lateinit var mPagerAdapter: PagerAdapter
    private var backgroundLayout: ImageView ?= null
    private lateinit var myButton : Button

    companion object {

        const val  KEY_CLICK_COUNT = "1"
        private val quoteContents = arrayOf(

                "ከወንዶች ነፃ የሆነ አለም እንዴት ደስ ይል ይሆን? ምንም አይነት ወንጀል አይኖርም… ብዙ ወፋፍራም ደስተኛ ሴቶች ፈታ ብለዉ ይኖሩ ነበር፡፡ \n\n~ኒኮል ሆላንደር~",
                "ምርጥ ሴቶች ወደገነት ሲሄዱ እርኩሶቹ ሴቶች ግን የትም ይሄዳሉ\n\n~ሄለን ጉርሌ~",
                "ወንዶች ሁለት አይነት ስሜት ያሳያሉ፡፡ ረሃብና የወሲብ ስሜት፡፡ የወሲብ ስሜት እንደሌለዉ ካወቅሽ ቶሎ ሳንዱዊች ስሪለት\n\n~ያልታወቀ ሰዉ~",
                "ወንድን ካስተማርክ ብቻዉን ታስተምራለህ ፣ሴትን ካስተማርክ ግን ትዉልድን ታስተምራለህ\n\n~ብሪግሃም ያንግ~",
                "ለምን ይሆን ሴቶች ወንዶችን ከሚፈልጉት በላይ በወንዶች የሚፈለጉት?\n\n~ ቨርጂኒያ ዉልፍ~",
                "የወንድ የፊቱ ገፅታ የህይወት ታሪኩን ሲናገር የሴት ፊት ደግሞ የልብ ወለድ ስራዋን ይናገራል\n\n~ኦስካር ዊልዴ~",
                "ሁሉም ወንዶች እኔን መጠበቅ ይፈልጋሉ፡፡ ከምን እንደሚጠብቁኝ ግን ፈፅሞ ላዉቅ አልቻልኩም፡፡\n\n~ሜ ዌስት~",
                "የወንደላጤነት ህይወት ምርጥ ቁርስ፣ደህና ምሳና ደባሪ ራት ነዉ፡፡ \n\n~ፍራንሲስ ቤከን~" ,
                "እድሜዉ ትልቅ የሆነ ወንደላጤን ማግባት ያረጀ ፈርኒቸር እንደመግዛት ይቆጠራል  \n\n~ጃክሰን ብራዉን~" ,
                "ከማንኛዋም ቁጡ ሴት ጀርባ ክፉ ነገር ስለመስራቱ ምንም የማያዉቅ ወንድ አለ \n\n~ብሬኒኮትስ~" ,
                "ወንዶች ለመዋሸት ሲፈጠሩ ሴቶች ደግሞ እነሱን ለማመን ተፈጥረዋል \n\n~ሾን ጌ~" ,
                "ሴቶች እንደስሜታቸዉ ሲያረጁ ወንዶች ደግሞ ስሜታቸዉ ሲጠፋ ያረጃሉ \n\n~ሜ ዌስት~" ,
                "ሄዋን ሰይጣንን በግሏ ለማግኘት አዳምን ተለየችዉ   \n\n~አሌክሳንደር ፖፕ~" ,
                "አዳም እስከነግራ አጥንቱ ቢሞት ደስ ይለኝ ነበር  \n\n~ዲዬን ቦይሲካዉት~" ,
                "ወንዶችን የምወዳቸዉ ወንድ ስለሆኑ ሳይሆን ሴት ስላልሆኑ ነዉ \n\n~ንግስት ክርስቲና~" ,
                "እኛ ወንዶች ምን እያሰብን እንደሆነ ሴቶች ቢያዉቁ  በጥፊ መማታታቸዉን አያቆሙም ነበር  \n\n~ሌሪ ሚለር~s" ,
                "እስኪ ስለራስሽ፣ስላጋጠሙሽ የህይወት መሰናክሎች፣ስለህልሞችሽ እና ስልክ ቁጥርሽን ስጪኝ \n\n~ያልታወቀ ሰዉ~" ,
                "በአእምሮ ህመምተኞች ክፍል ዉስጥ ከሴቶች ይልቅ የወንዶች ቁጥር ይበዛል፤ይህ የሚያሳየዉ ማን ማንን እያሳበደ እንደሆነ ነዉ፡፡ \n\n~ፒተር ቬል~" ,
                "ወንዶች ሁል ጊዜ ከማያዉቁት ሰዉ ጋር በጣም ጠቃሚ ስለሆኑ ነገሮች ያወራሉ \n\n~ጂኬ ቸስተርተን~",
                "የሴት ልጅ ጭንቅላት ከወንድ ልጅ ይልቅ ንፁህ ነዉ ምክንያቱም ሴት ብዙ ጊዜ  አእምሮዋን ትቀያይረዋለች፡፡\n\n~ኦሊቨር ሄርፎርድ~", "ወንድ ልጅ ለሴት ልጅ የመኪና በር ከከፈተላት ወይ አዲስ ሙሽሮች ናቸዉ አለዚያ አዲስ መኪና ገዝተዉ ነዉ፡፡ \n\n~ፕሪንስ ፊሊፕ~", "ሴቶች ወሲብ ለማድረግ ምክንያት ይፈልጋሉ ወንዶች ግን ቦታ ብቻ ይፈልጋሉ! \n\n~ቢሊ ክሪስታል~", "ሴትን ልጅ ለሶስት ቀን ከጎኔ ካጣሁ ከባድ ራስ ምታት ይይዘኛል\n\n~ጆን ኤፍ ኬኔዲ~", "የምትወደኝ ዉብ ስለሆንኩ ነዉ ወይስ ዉብ የሆንኩት ስለምትወደኝ ነዉ? \n\n~ኦስካር አሚርስተን~", "ልዩ ሴት ከሆነች በቀላሉ አትገኝም፤ተራ ሰዉ ከሆነች ልዩ አትሆንም፤ዋጋ ካላት እሷን ለማግኘት ተስፋ ልትቆርጥ አትችልም…ግን ተስፋ ከቆረጥክ አንተ ራስህ ተራ ሰዉ ነህ፡፡\n\n~የማይታወቅ ሰዉ~", "ሴቶች በራሱ የሚተማመን ራሰ በራ ወንድ ይወዳሉ \n\n~ሌሪ ዴቪድ~", "ብዙ ወንዶች የህይወት መሰናክልን ያልፉታል..ግን ማንነታቸዉን ማወቅ ከፈለክ ስልጣን ስጣቸዉ ፡፡ \n\n~አብርሀን ሊንከን~", "ሴቶች የወሲብ እርካታ እንዳገኙ መስለዉ ሲሸውዱ ወንዶች ደግሞ የፍቅር ግንኙነትን የእዉነት አስመስለዉ ይኖራሉ \n\n~ሻሮን ስቶን~", "ጨረቃና ከዋክብት የሚያቀርብልሽን ወንድ አትመኚዉ ምክንያቱም እጁ ያን ያህል ረጅም እንዳልሆነ እግዚአብሄር ያዉቃል! \n\n~ኢቭ~", "ሴት ልጅ ወንድ ዉስጥ ማግኘት የምትፈልገዉን ነገር እራሷ ሳትገነባ እሱ እንዲሰራዉ ብትጠበቅ  በጣም እየተሸወደች  ነዉ  \n\n~አኒያስ ኒን~", "አዉሎ ንፋስና ቀሽም ሴቶች  አንድ ናቸዉ …ሲመጡ ያረጥቡሃል…ያቀዘቅዙሃል…ሲሄዱ ደግሞ ቤትህንና መኪናህን አጭቀዉልህ ነዉ!  \n" + "\n\n ~ዘቶፕ ቴንስ~", "ሴት ልጅ ‹ሂድ ተዝናና ችግር የለዉም› ስትልህ ነግሬሃለሁ እንዳትሄድ!ከሄድክ አለቀልህ!! \n\n~ሎልሶትሩ~", "ሴትን ልጅ ተናዳ ‹ተረጋጊ በቃ› ማለት ድመትን ዉሃ ዉስጥ እንደመክተት ያህል ነዉ \n\n~ሎልሶትሩ~", "ሴቶች ከአንድ ወንድ ብዙ ነገር ሲፈልጉ ወንዶች ደግሞ ከብዙ ሴቶች አንድ ነገር ይፈልጋሉ፡፡ \n\n~ፈኒ ኮትስ~", "በፍቅር ግንኙነት ዉስጥ ሶስት ነገሮችን እፈልጋለሁ፡ \n1.የማያለቅሱ አይኖች \n2.የማይዋሹ ከንፈሮች \nthunder.የማይሞት ፍቅር  \n\nሪኮትስ", "የምትወደዳት ከሆነ ልብህን እንጂ የልብ በሽታ አትስጣት  \n\n~ሪኮትስ~", "ልቤ ላንቺ ብቻ ይመታል  \n\n~ዊሽስ ፖየምስ~", "ወንዶች አያስታውሱም ሴቶች ደግሞ አይረሱም  \n\n~ያልታወቀ ሰዉ~", "ሴቶች ስላደረጉት ወሲብ ሲፀፀቱ ወንዶች ደግሞ ስላላደረጉት ወሲብ ይፀፀታሉ  \n\n~ክርስቲያን ረደር~", "ወንዶች ህይወትን በጊዜ ሲያዉቁ ሴቶች ግን አርፍደዉ ነዉ…ይኸዉ ነዉ ልዩነቱ! \n\n~ኦስካር ዊልዴ~", "ሴቶች ሲደብራቸዉ ወይ ምግብ ይበላሉ አለዚያ የሆነ ነገር ይገዛሉ…ወንዶች ሲደብራቸዉ ደግሞ የሰዉ ሀገር ይወራሉ  \n\n~ኤላይኔ ቡስለር~", "ሴቶች ከሚያፈቅሩት ወንድ ጋር ብዙ ጊዜ ወሲብ መፈፀም ሲፈልጉ ወንዶች ደግሞ ከብዙ ሴት ጋር ወሲብ ማድረግ ይፈልጋሉ  \n\n~ዴርሞንት ዴቪስ~", "ሴቶች የሚያስቃቸዉን ወንድ ሲፈልጉ ወንዶች ደግሞ የሚስቁላቸዉን ሴቶች ይፈልጋሉ  \n\n~ግሌን ገኸር~", "ወንዶች ወሲብ ለማድረግ ብለዉ ፍቅርን ይሰጣሉ ሴቶች ደግሞ ፍቅር ለማግኘት ብዉ ወሲብ ያደርጋሉ  \n\n~ያልታወቀ ሰዉ~", "ሚስትየዉ ሃጢያት ከሰራች ባልየዉ ንጹህ አይደለም \n\n~ጣልያናዊያን~", "ወንድ እስካላፈቀረ ድረስ ከማንኛዉም ሴት ጋር ደስተኛ ሆኖ ያሳልፋል  \n\n~ኦስካር ዊልዴ~", "ወንዱ ዶሮ ሊያስካካ ይችላል እንቁላል የምትጥለዉ ግን ሴቷ ዶሮ ነች  \n\n~ማርጋሬት ታቸር~", "ጥቂት ሴቶች ትክክለኛ እድሜያቸዉን ይናገራሉ…በጣም ጥቂት ወንዶች ደግሞ እንደ እድሜያቸዉ ይኖራሉ \n\n~በምፐር ስቲከር~", "ሁሉም ሴቶች እናቶቻቸዉን ሲመስሉ ሁሉም ወንዶች ደግሞ በፍፁም አይመስሉም፡፡ \n\n~ኦስካር~", "ዉበት ቢራ በሚጨብጠዉ  ሰዉ ይወሰናል  \n\n~ብራድ ዊልከርሰን~", "ሴቶች አንተ የምታስበዉን ለማዳመጥ አይፈልጉም ፤እነሱ የሚፈልጉት የሚያስቡትን ነገር በጥንቃቄ እንድትሰማቸዉ ነዉ  \n\n~ቢል ኮዝቢ~", "ሴቶች በብዛት የሚጫወቱት የጨዋታ አይነት ‹ወንድ› ይባላል \n\n~አዳም ስሚዝ~", "ሴት ልጅ ከወንድ ማየት የምትፈልገዉን  ማንነቶች ለማግኘት ስትጥር ወንድ ልጅ ደግሞ ከሴት ስጋ የሚችለዉን   ሁሉ ለማግኘት  ይጥራል  \n\n~አይዛክ ጎልድበርግ~", " ምርጥ ጭንቅላት ያላቸዉ ወንዶች ከ ተራ ሴቶች ጋር ልታገኛቸዉ ትችላለህ ይሁን እንጂ  ምርጥ ሴቶችን ከ ተራ ወንድ ጋር አታገኛቸዉም፡፡ \n\n~ኤሪካ ጆንግ~", "እኔ እንደማስበዉ ወንዶች ሴቶችን በወሬ የሚያጣድፉት አብረዉ ለመተኛት ሲሆን ሴቶች ደግሞ አብረዉ የሚተኙት ወሬ ለማዉራት  ነዉ!\n\n~ጄይ ማክነርኔይ~", "ሴቶች ዝም የሚል ወንድ ይወዳሉ ምክንያቱም የሚያዳምጣቸዉ ይመስላቸዋል፡፡ \n\n~ማርሴል አቻርድ~", "ሴቶችን እጠላቸዋለሁ ለምን መሰለህ ነገሮች ያሉበትን ሁኔታ ሁሌም ያዉቃሉ፡፡ \n\n~ቮልቴር~", "ሴቶች እድሜያቸዉን ሲዋሹ ወንዶች ደግሞ ገቢያቸዉን ይዋሻሉ  \n\n~ዊልያም ፌዘር~", "ሴት  አለምን ልትቀይር ትችላለች ወንድ ልጅን ግን መቼም አትቀይርም፡፡ \n\n~ኤሚ ስኖዉደን~", "ምርጥ የሚባለዉ ወንድ አይባልግም፣አይጠጣም፣አያጨስም፣ቁማር አይጫወትም፣በአለም ላይ የለም  \n\n~ሞኒካ ሎዉስ~", "ወንዶች እንደዛፍ ናቸዉ…ለማደግ ዘላለም ይፈጅባቸዋል፡፡\n\n~ማዲሰንኢትስ~", "ቤት ያጣ ወንድ ካየህ አትዘንለት፣ሚስቱን መስማት የሱ ሃላፊነት ነበር፡፡ \n\n~ብሩክ~", "ህፃን ሴቶች ሲያድጉ እናቶች ሲሆኑ ህፃን ወንዶች ደግሞ ትልልቅ ወንዶች ይሆናሉ፡፡  \n\n~ፍሮስቲ~", "ወንዶች ሁለት ዉሸት ብቻ አለባቸዉ እሱም የሚናገሩት እና የሚያደርጉት ነገር ! \n\n~ታሊያ ሻየር~", "ጨረቃና ከዋክብት የሚያቀርብልሽን ወንድ አትመኚዉ ምክንያቱም እጁ ያን ያህል ረጅም እንዳልሆነ እግዚአብሄር ያዉቃል! \n\n~ኢቭ~", "በወንዶችና ባባቶች መካከል ያለዉ ልዩነት ያሻንጉሊቶቻቸዉ ዋጋ ነዉ \n\n~ዳን ሳፕካሮስኪ~", "ሁሉም ወንዶች ሊያዉቁት የሚገባዉ ነገር ቢኖር  ሴቷን እዚሁ  ለማቆየት ሁኔታዉ ርካሽ እንደሆነ ነዉ፡፡ \n\n~ጃኒን ሰተን~", "ወንድ ልጅ የሆነ ነገር እንዲሰራልሽ ከፈለክሽ ለስራዉ እድሜዉ እንዳለፈ ንገሪዉ \n\n~ኩልኤንስማርት~", "እርቀሽ ባልሽን፣ ቀርበሽ ደግሞ ወንደ ላጤን አትመኚዉ \n\n~ጆን ካሉምቡ~")

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen_slide)

        val statusBarSetting : Window = this.window
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){

            statusBarSetting.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            statusBarSetting.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            statusBarSetting.statusBarColor = ContextCompat.getColor(this,android.R.color.black)

        }


        mPager = findViewById(R.id.pager)
        myButton = findViewById(R.id.new_but)
        backgroundLayout = findViewById (R.id.backgroundImage)
        mAdView = findViewById(R.id.adView)


        mPagerAdapter = ScreenSlidePagerAdapter(supportFragmentManager)
        mPager.adapter = mPagerAdapter

        Glide.with(this).load(R.drawable.thunder).into(backgroundLayout)

        val adRequest = AdRequest.Builder().build()
        mAdView.loadAd(adRequest)


        myButton.setOnClickListener {

            val prefs = getPreferences(Context.MODE_PRIVATE)
            var clickCount = prefs.getInt(ContentOne.KEY_CLICK_COUNT,0)
            clickCount ++

            val sharingIntent = Intent(Intent.ACTION_SEND)
            sharingIntent.type = "text/plain"
            sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "ወንዶች")
            sharingIntent.putExtra(Intent.EXTRA_TEXT, quoteContents[mPager.currentItem])
            startActivity(Intent.createChooser(sharingIntent, "ሼር ያድርጉ!"))
            prefs.edit().putInt(ContentOne.KEY_CLICK_COUNT,clickCount).apply()


        }
    }

    inner class ScreenSlidePagerAdapter(fm: FragmentManager) : FragmentStatePagerAdapter(fm) {


        private val mCount = quoteContents.size

        override fun getItem(position: Int): Fragment {

            return  ViewPagerAdapter.newInstance(quoteContents[position % quoteContents.size])
        }

        override fun getCount(): Int = mCount

    }
}
