package com.afc.qewachquotes

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import android.support.v4.content.ContextCompat
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.bumptech.glide.Glide


class ContentTen: FragmentActivity() {

    private lateinit var mAdView: AdView
    private lateinit  var mPager: ViewPager
    private lateinit var mPagerAdapter: PagerAdapter
    private var backgroundLayout: ImageView ?= null
    private lateinit var myButton : Button




    companion object {

        const val  KEY_CLICK_COUNT = "1"
        private val quoteContents = arrayOf(

                "ፀሎት እግዚአብሄርን አይቀይረዉም ግን የሚፀልየዉን ሰዉ ይቀይረዋል\n\n ~ሶሬን ኪርክጋርድ~",
                "የተሻልክ ሆነህ መገኘት ያለብህ ከትናንትናዉ ማንነትህ ነዉ\n\n ~ያልታወቀ ሰዉ~",
                "ዝምታ በጣም ይጮሃል\n\n ~ሳራ ዴሰን~",
                "አንድ ቀን ተረት ለማንበብ እንኳን ጊዜዉ ያለፈብህ ሰዉ መሆንህ ይሰማሃል\n\n ~ሲኤስ ሉዊስ~",
                "ሰዎች ማንነታቸዉን ለመጀመሪያ ጊዜ ሲያሳዩህ እመናቸዉ\n\n ~ማያ አንጀሎ~",
                "አንድ ሰአት ያለምንም ስራ ለማባከን ሃሞቱ ያለዉ ሰዉ የህይወት ዋጋ አልገባዉም\n\n ~ቻርልስ ዳርዊን~",
                "ለመዝናናት ያዋልከዉ ጊዜ የባከነ ጊዜ አይደለም\n\n ~ጆን ሌኖን~",
                "እሳትን በእሳት ለመፋለም ለምታስቡ ሰዎች እባካችሁ እሳት አደጋ እንኳን እሳትን ለማጥፋት የሚጠቀመዉ ዉሃን ነዉ\n\n ~ያልታወቀ ሰዉ~",
                "ቤተሰብ ማለት ጠቃሚ የሆነ  ነገር አይደለም፤ ቤተሰብ  ሁሉ ነገር ነዉ\n\n ~ያልታወቀ ሰዉ~",
                "ዉሾች ባለቤት ሲኖራቸዉ ድመቶች ደግሞ ኮተት ይኖራቸዋል\n\n ~ያልታወቀ ሰዉ~",
                "ብዙ ሰዎች በ 25 አመታቸዉ ይሞቱና እስከ 75 አመታቸዉ ድረስ አይቀበሩም  \n\n~ቤንጃሚን ፍራንክሊን~" ,
                "ለመኖር ጊዜ ያጣን ባዶ ህይወት ተጠንቀቀዉ  \n\n~ሶቅራጠስ~" ,
                "ከሞከርክ ልትወድቅ ትችላለህ ካልሞከርክ ግን ፈፅሞ አትወድቅም  \n\n~ያልታወቀ ሰዉ~" ,
                "የሚያስፈልግህን ብቻ ከሰራህ ለመኖር እየሞከርክ ነዉ  የምትፈልገዉን ከሰራህ ግን እየኖርክ ነዉ  \n\n~ያልታወቀ ሰዉ~" ,
                "ዛሬን ኑር ነገ ታሪክ ይሆናል  \n\n~ያልታወቀ ሰዉ~" ,
                "ራስህን ሁን፡፡ሁሉም ሰዉ ተይዟል  \n\n~ኦስካር ዊልዴ~" ,
                "ህይወት ማለት ፕላንህን ለመፈፀም ጊዜ ባጣህበት ሰአት የሚከሰት ነገር ነዉ  \n\n~ጆን ሌኖን~" ,
                "ያልተፈተነ ህይወት ለመኖር ብቁ አይደለም   \n\n~ሶቅራጠስ~" ,
                "ደስተኛ ህይወት ከፈለክ ከሰዎች ወይም ከነገሮች ሳይሆን ከህልምህ ጋር እሰረዉ \n\n~አልበርት እንስታይን~" ,
                "ጥላቻ ህይወትን ያጨልማል ፍቅር ደግሞ ያበራዋል  \n\n~ማርቲን ሉተርኪንግ~" ,
                "የህይወት ትርጉሙ በትላልቅ ነገሮች መሸነፍ ነዉ  \n\n~ሪልኬ~",
                "ትግስት ማለት ከኋላህ ባለዉ ሹፌር  ድረጊት የምትገረምበት ፣ከፊትህ ባለዉ ሹፌር ደግሞ የምትናደድበት ሂደት ነዉ፡፡ \n\n~ቢል ማክግላሸን~",
                "ጋራጅ በመሄድህ መኪና ነህ እንደማትባል ሁሉ ቤተክርስቲያን በመሄድህ ብቻ ክርስቲያን አትባልም፡፡ \n" + "\n~ቢሊ ሰንደይ~",
                "ምርጥ ጀነራል የድል መንገድን ብቻ ሳይሆን ድል ማድረግ መቼ እንደማይቻልም ያዉቃል፡፡ \n" + "\n~ፖሊቢየስ~",
                "ሰዎች እጣ ፈንታቸዉን አያስተካክሉም፤እጣ ፈንታ ራሱ ሰዎችን በሚፈለገዉ ሰአት ያቀርባቸዋል፡፡\n" + "\n~ፊደል ካስትሮ~",
                "የታሪክ አንድ ጎኑ ብቻ ተደጋግሞ ሲሰማ የሰዉ ጭንቅላት ከመጠን በላይ ይደነቃል \n" + "\n~ጆርጅ ዋሽንግተን~",
                "ሻማ ሌላ ሻማን በማብራቱ ምንም የሚያጣዉ ነገር አይኖርም \n" + "\n~ኤሪን ማጀርስ~",
                "ጀግንነትህን የምታዉቀዉ መፍራትህን አንተ ብቻና ብቻ ስትረዳዉ ነዉ \n" + "\n~ዴቪድ ሃክዎርዝ~",
                "ያጋጠመን እዉነታ - ይሆናል ብለን ያሰብነዉ ነገር = ደስታ ይሆናል  \n" + "\n~ቶም ማግሊዎዚ~",
                "እዉነት ሶስት ነገሮችን ያልፋል…መጀመሪያ ይሾፍበታል ቀጥሎ ከፍተኛ ተቃውሞ ይደርስበታል በመጨረሻም እራሱ ምስክር በመሆን ተቀባይነትን ያገኛል \n" + "\n~አርተር ስኮፔንሃወር~",
                "እምነት ማለት እግዚአብሄር የምትፈልገዉን እንደሚያደርግልህ ማመን ሳይሆን እግዚአብሄር በስራዉ ትክክል መሆኑን ማመን ነዉ፡፡\n" + "\n~ማክስ ሉካዶ~",
                "ሁሉንም አበቦች ልትቆርጣቸዉ ትችላለህ ነገር ግን የሚመጣዉን ወቅት ማዘግየት አትችልም፡፡\n" + "\n~ፓብሎ ነሩዳ~",
                "እድሜ ልክ በግ ሆኖ ከመኖር ለአንድ ቀን አንበሳ ሆኖ ማለፍ ይሻላል፡፡\n" + "\n~ኤሊዛቤት ኬኒ~",
                "አንቀፅ አንድ፡ለእግዚአብሄር እኖራለሁ አንቀፅ ሁለት፡ ማንም ይህንን ባያደርግ እኔ አደርገዋለሁ፡፡ \n" + "\n~ጆናታን ኤድዋርድስ~",
                "ድሮ ሃጢአት የነበረ ነገር አሁን በሽታ ሆኗል፡፡ \n" + "\n~ቢል ማኸር~",
                "የአንድን ሰዉ ሃሳብ መስረቅ ኩረጃ ሲሆን የብዙ ሰዎችን ሃሳብ መስረቅ ሪሰርች ነዉ፡፡ \n" + "\n~ስቴቨን ራይት~",
                "በአለም ላይ ያለዉ ጨለማ ሁሉ የአንዲት ሻማን ብርሃን ሊያጠፋ አይችልም፡፡ \n" + "\n~ፍራንሲስ ኦፍ አሲሲ~",
                "ከዉጪ የሚያይ ያልማል ከዉስጥ የሚያይ ግን ይነቃል \n" + "\n~ካርል ጀንግ~",
                "ሰዎች ስለራሳቸዉ የተለየ ስሜት እንዲሰማቸዉ ማድረግህ ስላንተ ማንነት ይናገራል፡፡ \n" + "\n~ኩሻንድ ዊዝደም~",
                "መጥፎ አሰራር መልካም የሆነዉን ሰዉ ሁልጊዜ ያሰቃየዋል፡፡ \n" + "\n~ደብሊዉ ኤድዋርድስ  ዴሚንግ~",
                "ባለህበት ቦታ ሆነህ ባለህ ነገር የምትችለዉን  ሁሉ አድርግ \n" + "\n~ቴዲ ሩዝቬልት~",
                "ቀላሉ የህይወት መንገድ በቆሻሻ ስፍራ ያልፋል \n" + "\n~ጆን ማድን~",
                "ብዙ ጊዜ ማድረግ የምንፈራዉ ነገር ማድረግ የሚገባንን ነዉ \n" + "\n~ቲም ፌሪስ~",
                "የምትወደዉን ነገር ስራ ከዛ ገንዘብ ይከተልሃል \n" + "\n ~ማርሻ ሲንታር~",
                "በፊትህ ብትወድቅም መሄድክን አሁንም አላቆምክም \n" + "\n~ቪክቶር ኬም~",
                "ለማንኛዉም ነገር ዋጋ የምታወጣለት ዋጋ በከፈልክበት የህይወት መጠን ልክ ነዉ \n" + "\n ~ሄንሪ ዴቪድ~",
                "ሰነፍ ሰዉ ጠንክረዉ ለሚሰሩ ሰዎች ‹ልክፍት› ብሎ ቃል ፈጠረ \n" + "\n~ረስል ዋረን~",
                "‹የሆነ ቀን› የሚለዉ ቃል ከሳምንቱ ቀናት ዉስጥ የለም \n" + "\n~ዴኒስ ብሬናን~", "ጉዞህን ካልጨረስከዉ ለምን ጀመርከዉ  \n" + "\n~ጆ ናማት~",
                "አትሞክር::ወይ ስራ: ወይ ተወዉ..እዚህ ሙከራ የለም  \n" + "\n~ዮዳ~",
                "ነገሮች ቀላል እንዲሆኑ አትመኝ ..አንተ ራስህ የተሻልክ ለመሆን ጣር  \n" + "\n~ጂም ሮን~",
                "የብዙ ሺህ ጫካ አፈጣጠር በአንድ ችግኝ ይጀምራል \n" + "\n ~ራልፍ ዋልዶ~",
                "ኖህ መርከቡን ሲሰራ ዝናብ እየዘነበ አልነበረም  \n" + "\n ~ሃዋርድ ረፍ~",
                "መቼም ቢሆን ትዝታህ ህልምህን እንዳይበልጠዉ! \n" + "\n~ዶዉግ ኢቬስተር~",
                "የመጨረሻ እስትንፋስህን እስክትተነፍስ ድረስ የህይወትን ዋጋ መቼም አታዉቀዉም  \n" + "\n~ዴባሲሽ ምሪድሃ~",
                "የልብ ምትህ ሲቆም ብቻ ተስፋ ቁረጥ  \n", "\n~ፋሃድ ራሺቅ~", "ይህ የመጨረሻ ትንፋሼ ነዉ...ምን እንዳደርግልህ ትወዳለህ ? \n" + "\n~ቺር ልዩድ~",
                "እንደ ቆራጥ ወታደር ችግሮችህን ተዋጋቸዉ..እንደተሳሳተ ሰዉ አዳምጥ  \n" + "\n~ሮበርት ሰተን~",
                "ልጆች ማለት ወደፊት ለማናየዉ ጊዜ የምንልካቸዉ መልእክቶች ናቸዉ  \n" + "\n~ጆን ኤፍ ኬኔዲ~",
                "የመጀመሪያዉ ሰዉ አስኳሉን ያገኛል ሁለተኛዉ ደግሞ ቅርፊቱ ይደርሰዋል \n" + "\n~አንድሪዉ ካርንጌ~",
                "ርካሹ ነገር በጣም ዉድ ነዉ፡፡ \n" + "\n~ጀርመኖች~", "አለማወቅ ያስጠላል..ላለማወቅ መፈለግ ደግሞ የባሰ ደባሪ ነገር ነዉ   \n" + "\n~ናይጄሪያዊያን~",
                "ብልህ ሰዉ አንድ ቃል ሰምቶ ሁለት ቃል ይገባዋል \n" + "\n~ዪዲሽ~",
                "ተቃዉሞ እንደ ፖም ፍሬ በስሎ የሚወድቅ አይደለም ፡፡እንዲወድቅ ማድረግ ያንተ ሃላፊነት ነዉ፡፡ \n" + "\n~ቼጉቬራ~",
                "ጠላትህ ይስማማል ጓደኛህ ግን ይከራከራል \n" + "\n~ራሺያዊያን~", "ለማኝ ሰዉ መራጭ ሊሆን አይችልም \n" + "\n~ጆን ሄይዉድ~", "ጨለማዉን ከመርገም ሻማዉን መለኮስ ይሻላል \n" + "\n~ቻይናዊያን~",
                "ሴትንና ጨርቅን በሻማ ብርሃን አትምረጥ  \n" + "\n~ጣልያዊያን~", "መወቀስ ከፈለክ አግባ  \n" + "\n~አይሪሽ~", "አንድ ነገር በሶስት ሰዎች ከተሰማ ሚስጥርነቱ ይቀራል \n" + "\n~አይሪሽ~",
                "ጎረቤቶችህን ዉደድ ግን አጥርህን አታፍርስ  \n" + "\n~ቻይናዊያን~")

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen_slide)

        val statusBarSetting : Window = this.window
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){

            statusBarSetting.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            statusBarSetting.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            statusBarSetting.statusBarColor = ContextCompat.getColor(this,android.R.color.black)

        }


        mPager = findViewById(R.id.pager)
        myButton = findViewById(R.id.new_but)
        backgroundLayout = findViewById (R.id.backgroundImage)
        mAdView = findViewById(R.id.adView)

        mPagerAdapter = ScreenSlidePagerAdapter(supportFragmentManager)
        mPager.adapter = mPagerAdapter

        Glide.with(this).load(R.drawable.mix).into(backgroundLayout)


        val adRequest = AdRequest.Builder().build()
        mAdView.loadAd(adRequest)


        myButton.setOnClickListener {

            val prefs = getPreferences(Context.MODE_PRIVATE)
            var clickCount = prefs.getInt(ContentOne.KEY_CLICK_COUNT,0)
            clickCount ++

            val sharingIntent = Intent(Intent.ACTION_SEND)
            sharingIntent.type = "text/plain"
            sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "የህይወትን ዋጋ..")
            sharingIntent.putExtra(Intent.EXTRA_TEXT, quoteContents[mPager.currentItem])
            startActivity(Intent.createChooser(sharingIntent, "ሼር ያድርጉ!"))
            prefs.edit().putInt(ContentOne.KEY_CLICK_COUNT,clickCount).apply()


        }
    }

    inner class ScreenSlidePagerAdapter(fm: FragmentManager) : FragmentStatePagerAdapter(fm) {


        private val mCount = quoteContents.size

        override fun getItem(position: Int): Fragment {

            return  ViewPagerAdapter.newInstance(quoteContents[position % quoteContents.size])
        }

        override fun getCount(): Int = mCount

    }

}
