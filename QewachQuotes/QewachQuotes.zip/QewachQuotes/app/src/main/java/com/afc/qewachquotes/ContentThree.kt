package com.afc.qewachquotes

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import android.support.v4.content.ContextCompat
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.bumptech.glide.Glide


class ContentThree : FragmentActivity() {

    private lateinit var mAdView: AdView
    private lateinit  var mPager: ViewPager
    private lateinit var mPagerAdapter: PagerAdapter
    private var backgroundLayout: ImageView ?= null
    private lateinit var myButton : Button




    companion object {

        const val  KEY_CLICK_COUNT = "1"
        private val quoteContents = arrayOf(

                "አባቶቻችን ስለ አለም ሃገራት የሚቆረቆሩ ቢሆኑ ኖሮ የነፃነት አዋጅ አያዉጁም ነበር  \n\n~ስቴፈን ኮልበርት~",
                "አንበሳ ከጥጃ ጋር አብሮ ሊተኛ ይችላል ጥጃዋ ግን መቼም እንቅልፍ አይወስዳትም  \n\n~ዉዲ አለን~",
                "በእዉነትና በልብወለድ መካከል ያለዉ ልዩነት ምንድነዉ? ልዩነቱ ልብወለድ ስሜት ይሰጣል፡፤\n\n~ቶም ክላንሲ~",
                "ህብረተሰቡ እራስህን እንድትሆን ፈቃድ እንዲሰጥህ አትጠይቅ\n\n~ስቲቭ ማርቦሊ~",
                "ከፍርሃቱ ሸሽቶ የሚሮጥ ሰዉ የገዛ ፍርሃቱን በአቋራጭ ያገኘዋል፡፡\n\n~ሳዶር~",
                "ህይወት አስቸጋሪ ናት፡፡ ማሰብ የማትችል ከሆንክ ደግሞ የበለጠ ታስቸግርሃለች\n\n~ጆርጅ ሂጊንስ~",
                "በህይወት ያሉ ድራጎኖች ላይ መቼም ቢሆን እንዳትስቅ \n\n~ጄአርአር ቶኬይን~",
                "ማንም የማያዉቀውን የግል ህመም ችሎ መኖርን የሚያክል ህመም የለም ፡፡ \n\n~ማያ አንጄሎ~",
                "በመጨረሻ ሁላችንም ታሪክ ነን፡፡\n\n~ስቴቭን ሞፋት~",
                "የምትሄድበትን ካላወቅክ ሁሉም መንገድ የትም ያደርሃል\n\n~ጆርጅ ሃሪሰን~",
                "በዉሸት ከመደላደል በእዉነት መጎዳት ይሻላል፡፡\n\n~ካሊድ ሆሴኒ~",
                "ህይወቴን መቀየር የምችለዉ እኔዉ ራሴ ነኝ፡፡ማንም መጥቶ ህይወቴን ሊቀይር  አይችልም\n\n~ካሮል በርኔት~",
                "ብዙ ጊዜ ሰዎች ጥለዉት የሚሄዱት አሻራ ጠባሳ ይባላል\n\n~ጆን ግሪን~",
                "ህመም ለጊዜዉ ነዉ፡፡ ነገሮችን ማቋረጥ ግን የዘላለም ነዉ፡፡\n\n~ላንስ አርምስሮንግ~",
                "ሰዎች ማንነታቸዉን ለመጀመሪያ ጊዜ ሲያሳዩህ እመናቸዉ፡፡\n\n~ማያ አንጀሎ~",
                "እድሜህ ስንት እንደሆነ ባታዉቅ ኖሮ እድሜህ ስንት ይሆን ነበር?\n\n~ሳችል ፔግ~",
                "ሞት ህይወትን ይቋጫል ግንኙነትን ግን አያስቆምም\n\n~ሚች አልቦም~",
                "ሃሳብህ ግራ ሊያጋባህ ይችላል ስሜትህ ግን መቼም ዋሽቶ አያዉቅም\n\n~ሮበርት ኤበርት~",
                "የሞቴ ቀን የተነበበዉ የህይወት ታሪክ በጣም የተጋነነ ነዉ\n\n~ማርክ ትዌይን~",
                "በ 20 አመት ዉስጥ ይሄንን ጊዜ ፈፅሞ ላታስታዉሰዉ ትችላለህ\n\n~ያልታወቀ ሰዉ~",
                " መልካም ነገር ለማድረግ ጊዜ ያጣ ሰዉ መልካም ለመሆንም ጊዜ አይኖረዉም  \n\n~ሪቢንድራት ታጎር~",
                "ትክክል ካልሆነ አታድርገዉ፣እዉነት ካልሆነ አትናገር   \n\n~ማርከስ ኤዉሬሊየስ~" ,
                "ልጅ ለማሳደግ ሰፈር ያስፈልጋል \n\n ~አፍሪካዊያን~" ,
                "ነገሩን ቀለል አርገዉ…ግን አትልቀቀዉ፡፡ \n\n~ዉዲ ጉትራይ~" ,
                "ምንም የማይጠብቅ ሰዉ የተባረከ ነዉ ምክንያቱም መቼም ቢሆን አይናደድም   \n\n~ጆናታን ስዊፍት~" ,
                "አይን ያጠፋዉን ሰዉ አይን ማጥፋት አለምን ሁሉ እዉር ያደርጋል፡፡ \n\n~ማህተመ ጋንዲ~" ,
                "አስተሳሰብህን ቀይር ከዛ አለምን ትቀይራለህ  \n\n~ኖርማን ቬንሌት ፔል~" ,
                "ካረጀህ እራስህን ለመቀየር አትነሳ ግን አካባቢህን ለዉጥ  \n\n~ቢኤፍ ሺነር~" ,
                "በዚህ አለም የእዉነት መኖር ብርቅዬ ነገር ነዉ፡፡ ብዙ ሰዎች እንደተፈጠሩ አሉ፡፡ \n\n~ኦስካር ዊልዴ~" ,
                "ችግርህን ለማንም አትንገር፡፡ 20 ፐርሰንቱ ስላንተ ግድ አይሰጣቸዉም 80 ፐርሰንቱ ደግሞ ችግርህን ስላጫወትካቸዉ ደስ ይላቸዋል፡፡ \n\n~ዪንግ ኢሜጅስ~",
                "ዉሸትን ከደጋገምከዉ ፖለቲካ ይሆናል \n\n~ ሞኸል~",
                "በተቻለ መጠን አእምሮአችንን ክፍት እናድርግ ግን መሬት እንዳንጥለዉ ጠንቀቅ! \n\n~ሪቻርድ ዳውኪንስ~",
                "ቅጥረ ገዳይ እስካሎንክ ድረስ ማንነትህን ተቀበለዉ፡፡\n\n~ኤለን ዲጅንረስ~", "ወይ ምራኝ ወይ ተከተለኝ አለበለዚያ ግን መንገዴን ልቀቅ፡፡\n\n~ጀነራል ጆርጅ ፓቶን~", "መሪ ማለት መንገድን የሚያዉቅ፣ ባወቀበት መንገድ የሚሄድና ለሌላዉ የሚያሳይ ሰዉ ነዉ፡፡\n\n~ጆን ማክስዌል~", "ምንም ሁን ምን ምርጥ ሁን፡፡\n\n ~አብርሀማ ሊንከን~", "ሳንቲሞች ከሰማይ ሊዘንቡ አይችሉም፡፡እዚሁ ምድር ላይ ይገኛሉ፡፡ \n\n~ማርጋሬት ታቸር~", "እዉነታን ቀድሞ እንደነበረ ወይም እንደምኞትህ ሳይሆን አሁን እንዳለበት ሁኔታ ተጋፈጠዉ ፡፡\n\n~ጃክ ዌልች~", "ሞትን በጣም አትፍራ ጎዶሎ ህይወትን ግን ፍራ፡፡\n\n~በርቶሊ ብሬችት~", "ጓደኞችህን አቅርባቸዉ የዛኔ ጠላቶችህን በደንብ ታቀርባለህ፡፡\n\n~ሱን ኢዙ~", "በህይወትህ ዉስጥ የምትፈልገዉን ነገር ለማግኘት የመጀመሪያዉ እርምጃ አንድ ነገር ነዉ፤ምን እንደምትፈልግ እወቅ፡፡\n\n~ቤን ስቴይን~", "ገንዘብ ለሁሉም መልስ ሊሆን አይችልም ግን ልዩነትን ያመጣል፡፡ \n\n~ባራክ ኦባማ~", "የመጀመሪያዉ መመሪያ አለመሸነፍ ሲሆን ሁለተኛዉ መመሪያ ደግሞ የመጀመሪያዉን መመሪያ አለመርሳት ነዉ፡፡ \n\n~ዋረን በፌት~", "አንድን ነገር ካልፈለከዉ ለዉጠዉ፡፡መለወጥ ካቃተህ አስተሳሰብህን ቀይር፡፡አታማርር! \n\n~ማያ አንግሎዉ~", "የበቀል ጉዞህን ከመጀመርህ በፊት ሁለት ጉድጓድ ቆፍር፡፡ \n\n~ኮንፊሺየስ~", "ሙቀቱን ካልቻልክ ከማድቤቱ ዉጣ፡፡ \n\n~ሃሪ ኤስ ትሩማን~", "ሁልጊዜ ጠላትህን ይቅር በለዉ፤ከዚህ በላይ የሚያናድድ ነገር ጠላትህ ሊገጥመዉ አይችልም፡፡ \n\n~ኦስካር ዊልዴ~", "አንተ ካልተስማማህ ማንም የበታችነት ስሜት እንዲሰማህ ሊያደርግ አይችልም፡፡\n\n~ኤሊያኖር ሩዝቬልት~", "እያንዳንዱን ሰዉ ልታስደስት አትችልም፤ልክ እንደዚሁ ሁሉንም ሰዉ እንዳንተ አይነት ማድረግ አትችልም፡፡\n\n~ኬቲ ኮዉሪክ~", "ዛሬ ከቀኖች ሁሉ የከፋ ወይም ምርጥ ይሁን አላዉቅም ግን ላረጋግጥልህ የምፈልገዉ ነገር ቢኖር ያለህ ቀን ዛሬ ብቻ ነዉ \n\n~አርት ቡችዋልድ~", " እባብ አይተህ ቶሎ ግደለዉ እንጂ እባቦችን ለማጥፋት ኮሚቴ አትምረጥ \n\n~ኢ ኤፍ ሸማቸር~", "በህይወትህ በጣም አስፈላጊዉ ነገር ስህተት ነዉ፤ፍፁም ሆነህ የምትማረዉ ምንም ነገር የለም \n\n~አዳም ኦስቦርን~", "ለዶክተር አትዋሽም፣ለጠበቃህም አትዋሽም ስለዚህ ለሰራተኞችህ አትዋሽ \n\n~ጎርደን ቤቱን~", "ወደ ከፍታህ ስትወጣ ለሰዎች ጥሩ ሁን ምክንያቱም ከከፍታህ ስትወርድ ታገኛቸዋለህ \n\n~ጂሚ ዱራንቴ~", "ከትዝታዎችህ ጋር እንጂ ከህልምህ ጋር አትሙት፡፡\n\n~ኳይት ኮትስ~", " ጠላቶች አሉህ?በጣም ጥሩ! በህይወትህ ዉስጥ ዋጋ እየከፈልክበት ያለ መልካም  ነገር አለ ማለት ነዉ፡፡\n\n~ዊንስተን ቸርችል~", "ዛሬን ያነበበ ነገን ይመራል፡፡\n\n~ማርጋሬት ፉለር~", "ጥርጣሬ ገዳይ ነገር ነዉ፡፡ ማን እንደሆንክና ለምን እንደምትኖር ማወቅ አለብህ፡፡\n\n~ጄኒፈር ሎፔዝ~", "የትም ሂድ የት ልብህን ይዘህ ሂድ፡፡\n\n~ኮንፊሺየስ~", "እራስህን አትገድበዉ፤ብዙ ሰዎች እራሳቸዉን በሚያስቡት ሀሳብ ልክ ብቻ ይገድቡታል፡፡አንድ ነገር አስታዉስ ባመንከዉ ልክ ታገኛለህ፡፡ \n\n~ሜሪ ኬይ አሽ~", "የሌሎች የሃሳብ ጫጫታ የዉስጥህን ድምፅ እንዲዉጡት አትፍቀድላቸዉ፡፡ \n\n~ስቲቭ ጆብስ~", "ብር ማሯሯጥህን ተዉና ፍላጎትህን ተከተል፡፡\n\n~ቶሚ ሲ~", "ከአሳማ ጋር በፍፁም አትላፋ ምክንያቱም ሁለታችሁም ስትቆሽሹ አሳማዉ ይደሰታል፡፡\n\n~ካሌ ያርቦሮዉ~", "የማትችለዉ ነገር በምትችለዉ ነገር ዉስጥ ጣልቃ እንዲገባ አትፍቀድለት! \n\n~ጆን ዉድን~", "እችላለሁ ልትል ትችላለህ... እኔ አልችልም ብለህ ልትደመድምም ትችላለህ ግን እንዳልከዉ ትክክል ነህ  \n\n~ሄነሪ ፎርድ~", "ጠላቶችህን ይቅር በላቸዉ ስማቸዉን ግን መቼም እንዳትረሳ  \n\n~ጆን ኤፍ ኬኔዲ~", "እያንዳንዱን ቀን በሰበሰብከዉ ምርት ሳይሆን በዘራኸዉ ዘር መዝነዉ \n\n~ሊንክዲን ኮትስ~", "ተራራዉ ላይ አለም እንዲያይህ ሳይሆን አለምን ለማየት ዉጣ  \n\n~ሊንክዲን ኮትስ~", "የሆነ ሰዉ ጥሩ እድል ቢሰጥህና እንደምትሰራዉ እርግጠኛ ባትሆንም እሰራዋለሁ ብለህ ተቀበል ከዛም እንዴት መስራት እንዳለብህ  በኋላ ተማር \n\n~ሪቻርድ ብራንሰን~", "አንድ የድሮ ኬሚስት ለተማሪዎቹ እንዲህ አለ ‹ምንም ያህል የብቸኝነትና የመገፋት ስሜት ቢሰማህም ስራህን በትክክልና በትጋት ከሰራህ የማያዉቁህ ሰዎች አንተን ፈልገዉ ይመጣሉ፡፡› \n\n~ካርል ጀንግ~", "ልጅህን እንዴት ሀብታም መሆን እንዳለበት አታስተምረዉ ይልቁንስ ደስተኛ እንዲሆን አስተምረዉ..ምክንያቱም ሲያድግ የነገሮችን ጥቅም እንጂ ዋጋቸዉ አያስጨንቀዉም፡፡\n\n~ዩዝፉል ጅን~", "ሰዉ ባይገነዘብህም ትክክለኛ ነገር ስራ ምክንያቱም ለነገሮች ቁርጠኛ መሆንህን ቀኑ ሲደርስ ሁሉም ያዉቀዋል፡፡ \n\n~ሊንክዲን ኮትስ~", "የስኬትን ጉዞ ስትጀምር ያለምንም መሰላቸት አላማህ ላይ ብቻ አተኩር \n\n~ሌስ ብራዉን~", "ከዚህ በፊት ያልነበረህን ነገር እንዲኖርህ ከፈለክ ከዚህ በፊት ያላደረከዉን ነገር ደፍረህ ማድረግ ይጠበቅብሃል፡፡ \n\n~ያልታወቀ ሰዉ~", "በጣም ምርጥ የምትላቸዉን ቀናት ለማየት ከፈለክ መጥፎዉን ቀናት ማለፍህ የግድ ነዉ፡፡\n\n~ሊንክዲን ኮትስ~", "በስኬት መንገድ እንድትጓዝ መንገድ ያሳየህን ሰዉ መቼም እንዳትረሳዉ! \n\n~ጀስት ኢኖቬት~", "ብልህ ሰዉ ለብቻዉ የህይወቱን ጉዞ ለቀጥል ይችላል..ደካማ ሰዉ ግን በሰዎች ትርምስ ዉስጥ እራሱን ደብቆ ይኖራል  \n\n~ሰን ጌዚንግ~", "አንዳንዴ ተሳካም አልተሳካም ፍርሃታችንን አስፈራርተነዉ መጓዝ ግድ ይለናል..ምክንያቱም ይህ የገሃዱ አለም እዉነት ነዉ  \n\n~አሌክስ ኤሌ~", "ፊትህን ብርሀን ላይ አድርግ ምክንያቱም ጥላህን መቼም አታየዉም  \n\n~ሄለን ኬለር~", "ያላሰብከዉ ልዩ ህልም የሚከሰተዉ ስትነቃ ነዉ  \n\n~ቼሪ ጊልደርብሉም~", "ትክክለኛዉ መንገድ ላይ ብትሆንም ዝም ብለህ ከተቀመጥክ ትረጋገጣለህ  \n\n~ዊል ሮገርስ~")

    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen_slide)

        val statusBarSetting : Window = this.window
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){

            statusBarSetting.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            statusBarSetting.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            statusBarSetting.statusBarColor = ContextCompat.getColor(this,android.R.color.black)

        }


        mPager = findViewById(R.id.pager)
        myButton = findViewById(R.id.new_but)
        backgroundLayout = findViewById (R.id.backgroundImage)
        mAdView = findViewById(R.id.adView)

        mPagerAdapter = ScreenSlidePagerAdapter(supportFragmentManager)
        mPager.adapter = mPagerAdapter

        Glide.with(this).load(R.drawable.faith).into(backgroundLayout)


        val adRequest = AdRequest.Builder().build()

        mAdView.loadAd(adRequest)


        myButton.setOnClickListener {

            val prefs = getPreferences(Context.MODE_PRIVATE)
            var clickCount = prefs.getInt(ContentOne.KEY_CLICK_COUNT,0)
            clickCount ++

            val sharingIntent = Intent(Intent.ACTION_SEND)
            sharingIntent.type = "text/plain"
            sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "አባቶቻችን...")
            sharingIntent.putExtra(Intent.EXTRA_TEXT, quoteContents[mPager.currentItem])
            startActivity(Intent.createChooser(sharingIntent, "ሼር ያድርጉ!"))
            prefs.edit().putInt(ContentOne.KEY_CLICK_COUNT,clickCount).apply()


        }
    }

    inner class ScreenSlidePagerAdapter(fm: FragmentManager) : FragmentStatePagerAdapter(fm) {


        private val mCount = quoteContents.size

        override fun getItem(position: Int): Fragment {

            return  ViewPagerAdapter.newInstance(quoteContents[position % quoteContents.size])
        }

        override fun getCount(): Int = mCount

    }
}
