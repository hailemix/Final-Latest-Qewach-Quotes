package com.afc.qewachquotes

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import android.support.v4.content.ContextCompat
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.bumptech.glide.Glide


class ContentTwo : FragmentActivity() {

    private lateinit var mAdView: AdView
    private lateinit  var mPager: ViewPager
    private lateinit var mPagerAdapter: PagerAdapter
    private var backgroundLayout: ImageView ?= null
    private lateinit var myButton : Button


    companion object {

        const val  KEY_CLICK_COUNT = "1"
        private val quoteContents = arrayOf(
                "አንዳንድ ሰዎች በጣም ይንከባከቡሃል፡፡ እኔ ይህንን ፍቅር እለዋለሁ\n\n~ ኤ ሚላይን~",
                "የምታፈቅረዉና የሚያፈቅርህ ሰዉ ማንነት መቼም ቢሆን አንድ ሊሆን አይችልም\n\n~ቸክ ፓላኒክ~",
                "ፍቅር እንደቫይረስ ነዉ፡፡ ማንም ሰዉ ላይ በየትኛዉም ጊዜ ሊከሰት ይችላል\n\n~ማያ አንጀሎ~",
                "አንዳንድ ሰዎች በጣም ይንከባከቡሃል፡፡ እኔ ይህንን ፍቅር እለዋለሁ\n\n~ኤ ሚላይን~",
                "የፍቅር ጠላቱ ጥላቻ ሳይሆን ቸልተኝነት ነዉ፡፡ \n\n~ኤሊ ዊስሊ~",
                "ህይወት አበባ ናት፡፡ ፍቅር ደግሞ ማር ነዉ፡፡  \n\n~ቪክቶር ሁጎ~",
                "ፍቅር ይኑርህ፡፡ ፍቅር ሊከዳህ ወይም አጎሳቁሎ ባሪያ ሊያደርግህ አይችልም ነገር ግን ነፃ ያወጣሃል፡፡ \n\n~መምፎርድስ ኤንድ ሰንስ~",
                "ፍቅር በአንድ ነፍስ ዉስጥ ግን ሁለት ስጋ ስር ተሸፍኖ የሚኖር ነገር ነዉ፡፡ \n\n~አርስቶትል~",
                "በህልምና በፍቅር ዉስጥ አይቻልም የሚባል ነገር የለም፡፡ \n\n~ጃኖስ አርናይ~",
                "ለፍቅር በደንብ ከማፍቀር በቀር ምንም መድሀኒት የለዉም፡፡ \n\n~ሄንሪ ዴቪድ ትሮ~",
                "ነፍሳችን በምንም አይነት ነገር ቢሰራ የኔና የሱ ነፍስ አንድ አይነት ነዉ፡፡ \n\n~ዊዘሪንግ ሄይትስ~",
                "ሞት እዉነተኛ ፍቅርን ሊያስቀር አይችልም፡፡ሊያደርግ የሚችለዉ ለጊዜዉ ማዘግየት ነዉ፡፡ \n\n~ዘፕሪንሰስ ብራይድ~",
                "ፍቅር ትንሽ አለም ነዉ፡፡ሰዎች ትልቅ ያደርጉታል፡፡ \n\n~ያልታወቀ ሰዉ~",
                "ፍቅር በፍቅር ሆነህ ከ 2 አመት በላይ ከቆየህ የሆነ አሪፍ ደረጃ ደርሰሃል ማለት ነዉ፡፡ \n\n~ፍራን ልቦዊዝ~",
                "ፕሮፌሰር ሲያስተምር ሰዉነታችን ዉስጥ ያለዉ ሴል ሁሉ እየሞተ በአዲስ ይተካል ይላል፡፡አሮጌ ሴሎቼ ሞተዉ አንቺ ያልነካሽዉ አዲስ ሰዉነት አንድ ቀን ሲኖረኝ አቤት ደስታዬ!\n" +
                        "\n" + "~ዴይሊ ኮትስ~", "ምክንያት ሳይሆን ፍቅር ከሞት የበለጠ ሃይለኛ ነዉ፡፡\n" + "\n" +
                "~ቶማስ ማን~", "የሆነ ሰዉ አፍቅረህ ብዙ ጊዜ የማትገናኝ ከሆነ ፍቅርህ ካንገት በላይ ነዉ  \n" + "\n" +
                "~ናህት ሃን~", "ካንተ ለመለየት ሳስብ በአንድ ጊዜ አላደረኩትም ፣ ስለይህ ቀስ በቀስ ነበር…ግን ይሄን ማድረጌ የበለጠ ዉስጤን ገደለዉ ምክንያቱም ልታስቆመኝ እንኳን አልቻልክም! \n" + "\n" +
                "~ትሩዝ ኮትስ~", "አፍቅረዉ ብቻ የሚያገቡ ሰዎች ደባሪ ቀንና ምርጥ ምሽቶችን ያሳልፋሉ፡፡ \n" + "\n" +
                "~ግብፃዊያን~", "ስታፈቅር የሚገባህ ነገር ቢኖር አንድ ሲደመር አንድ ሁሉ ነገር ማግኘት ሲሆን፣ሁለት ሲቀነስ አንድ ደግሞ ሁሉን ነገር ማጣት ነዉ! \n" + "\n" +
                "~ሚግኖን ማክላሊን~", "ታማኝነት ልክ እንደመስታወት ነዉ..አንዴ ከተሰበረ እንደ ድሮ ማየት አይቻልም \n" + "\n" +
                "~ሳድ ኮትስ~", "ያልበሰለ ፍቅር ‹አፈቅርሻለሁ ምክንያቱም ታስፈልጊኛለሽ› ይላል የበሰለ ፍቅር ደግሞ ‹ታስፈልጊኛለሽ ምክንያቱም አፈቅርሻለሁ› ይላል   \n" + "\n" + "~ኤሪች ፍሮም~",
                "አንድ ፍቅረኛ ያላት ሴት መላእክት ነች፣ሁለት ፍቅረኛ ያላት ሴት አዉሬ ነች፣ሶስት ፍቅረኛ ያላት ሴት ግን ያዉ ሴት ነች! \n" + "\n" + "~ቪክቶር ሁጎ~",
                "እሱነቱ ላንቺ ሁሉ ነገርሽ ሆኖ አንቺነትሽ ለእሱ ምንም ነገር ሲሆንበት ማየት ልብን በጣም ያደማል  \n" + "\n" +
                        "~ትሩዝ ኮትስ~", "ፍቅር ያዘኝ ማለት በጣም ቀላል ነዉ.. በፍቅር ዉስጥ መቆየት ግን ልዩ መሆንን ይጠይቃል፡፡ \n" + "\n" +
                "~ፌቡ~", "ምርጡን ጎንሽን አይቼዋለሁ አስቸጋሪ ማንነትሽንም በደምብ አዉቃለሁ:ቢሆንም ሁለቱንም ተቀብያለሁ፡፡\n" +
                "\n" + "~ዚስቱ ሻ~", "ሚስቴ ጨለማ ትፈራለች… አሁን ግን በራቁቴ ስታየኝ መብራት ማብራቱን ፈራች  \n" + "\n" +
                "~ሮድኔይ ዳንገርፊልድ~", "ከትላንት ይልቅ ዛሬ ብወድሽም ነገ የማፈቅርሽ ግን ከዛሬ ይበልጣል  \n" + "\n" +
                "~ኤድሞንድ ሮዝታንድ~", "እንደማንኛዉም ተራ ነገር ከሚያይህ ሰዉ ጋር በፍቅር እንዳትወድቅ ተጠንቀቅ! \n" + "\n" +
                "~ኦስካር ዊልዴ~", "እወድሻለሁ፡ግን ከገመትኩት በላይ አንጀቴን እያቃጠልሺዉ ነዉ፡ ቢሆንም እያንዳንዱን የንዴት ደቂቃ ካንቺ ጋር ማሳለፍን እመርጣለሁ፡፡\n" + "\n" +
                "~ዴይሊ ኮትስ~", "ልጅ ኬክ እንደሚወደዉ እኔም አንቺን እወድሻለሁ፡፡ \n" + "\n" +
                "~ስኮት አዳምስ~", "በንፁህ ልብና በጥልቀት ወድጄህ እንደነበር ለብቻዬ ስሆን አሁን ገባኝ \n" + "\n" +
                "~ላቭ ኮትስ~", "የኒዉተን የፍቅር ህግ፡ 'ፍቅር አይፈጠርም…አይጠፋምም!ነገር ግን ፍቅር ከአንድ ገርልፍሬንድ ወደሌላ ገርልፍሬንድ በትንሽ ብር ኪሳራ የሚተላለፍ ሃይል ነዉ፡፡' \n" + "\n" +
                "~ቢቱ ጉብታ~", "ከሳቄ ጀርባ ልትረጂዉ የማትችይዉ ብዙ ነገር አለ\n\n " + "~ሳድ ኮትስ~", "ብዙ ክፍተቶች በመካከላችን ቢፈጠርም፣ምንም የሰራሽዉ ስህተት ህመሜን ቢያብሰዉም፣ወደፊት ብዙ የሚያንገበግቡና የሚያናድዱ ነገሮችን እንደምትሰሪ ባዉቅም..አንድ የማይለወጥ ማንነት በልቤ አለ ..ሁልጊዜ አፈቅርሻለሁ! \n" + "\n" +
                "~ሲጄ ሬድዋይን~", "በህይወት ዉስጥ ትዝታ ሆነዉ ከሚኖሩ ሰዎች ጥቂቶቹ የማይወደድ ማንነት እያለህ የሚወድዱህ ጓደኞችህ ናቸዉ  \n" + "\n" +
                "~ትሩዝ ኮትስ~", "መዉደዴ ልክ ዉሃ ዉስጥ ሰምጦ አየር ለማግኘት እንደሚጣጣር አይነት ሰዉ ነዉ... አየር በደምብ ካልሳበ እንደሚሞተዉ አንቺንም በትንሹ ካገኘሁ መሞቴ የአደባባይ ሚስጥር ነዉ ፡፡ \n" + "\n" +
                "~ረይ ካርሰን~", "ከዚህ የበለጠ ፍቅር ድሮም ተሰምቶኝ አያዉቅም ወደፊትም አይሰማኝም! \n" + "\n" +
                "~ማርጋሬት ስቶህል~", "አንዳንዴ አብሬሽ ስሆን እራሴን እንኳን በስርአቱ ማየት አልችልም…አንቺን ብቻና ብቻ ልቦናዬ ይመለከታል  \n" + "\n" +
                "~ታይገር ሊሊ~", "ሰዎችን ለመርሳት በሞከርክ ቁጥር የበለጠ እያስታወስካቸዉ ትመጣለህ \n" + "\n" +
                "~ትሩዝ ኮትስ~", "ካንተ ጋር የሚያስደነግጥና አደጋ የሆነ ፍቅር ይዞኛል  \n" + "\n" +
                "~ካሳንድራ ክሌር~", "የሚያፈቅር ልብ ሁልጊዜ ወጣት ነው  \n" + "\n" + "~ግሪኮች~",
                "ስትስቂ ከክዋክብት በላይ የደመቀ ፍንጣቂ ይታየኛል \n" + "\n" + "~ቤት ሬቪስ~", "ዋጋ ላለዉ ሰዉ መስዋእትነትን መክፈል የማንነቴ አካል ቢሆንም መስዋእት የሚከፈልለት ሰዉ አለመሆንሽን ዉስጤ ሲነግረኝ አዘንኩ   \n" + "\n" +
                "~ትሩዝ ኮትስ~", "ለፍቅር ዋጋ አትለጥፍለትም ግን ለመለዋወጫዎቹ ዋጋ መስጠት ትችላለህ፡፡ \n" + "\n" + "~ሜላኒ ክላርክ ፑለን~",
                "እንድወድቅ አደረክሺኝ፣እንደገና መቆም ፈፅሞ አልቻልኩም  \n" + "\n" + "~ሳድ ኮትስ~",
                "አሁንም ድረስ እወድሃለሁ.. ቢሆንም እየደማሁ እንድትሄድ ፈቅጄልሃለሁ….አፈቅርሃለሁ! \n" + "\n" + "~ፖፒዬ ካንዲ~", "ላንቺ ያለኝ ህመም መቼ ይሆን የሚቆመዉ..\n" + "\n" +
                "~ፖ.ካንዲ~", "በጣም ከምትወደዉ ሰዉ ብዙ ነገር እየጠበቅክ አሻራዉን ብቻ ጥሎ ከህይወትህ ሲወጣ ህመሙ ነፍስን ያቆስላል\n" + "\n" + "~ላቭ ኮትስ~",
                "የሚወዱህንና የሚያደንቁህን ሰዎች ንገረኝና ማንነትህን እነግርሃለሁ   \n" + "\n" + "~ቻርልስ ኦገስቲን~",
                "የማያፈቅር ልብ ከሚኖረኝ የማያዩ አይኖች፣የማይሰሙ ጆሮዎችና የማይናገር አንደት ቢኖረኝ ይሻላል! \n" + "\n" + "~ሮበርት ቲዞን~",
                "በእጃችን ላይ የያዝነዉን ማንነት እስከምንጥለዉ ድረስ ምንም አይሰማንም  \n" + "\n" +
                        "~ትሩዝ ኮትስ~", "ሰዎች ምክንያታዊ ያልሆኑ፣የማያስተዉሉና ራስ ወዳዶች ናቸዉ ቢሆንም መዉደድህን አታቋርጥ \n" + "\n" + "~ኬንት ኤም ኬይዝ~",
                "ምንም ሳያፈቅሩ ከመኖር አፍቅሮ ማጣት ይሻላል  \n" + "\n" + "~አልፍሬድ ቴኒሰን~",
                "‹እኔ አንድ ቀንም አስቀይሜህ አላዉቅም!› የሚሉ ሰዎች ከባዱን ጉዳት እንዳደረሱብህ ስታዉቅ የሰዉ ልጅ ምን ያህል ቀልደኛ እንደሆነ ይገባሃል  \n" + "\n" + "~ሳድ ኮትስ~",
                "በህልምና በፍቅር የማይቻል ነገር የለም ፡፡\n" + "\n" + "~ጃኖስ አርኔይ~",
                "ህይወትሽን ለኔ ባትሰጪኝም ህይወቴን በሙሉ ላንቺ እሰጥ ነበር \n" + "\n" + "~ትሩዝ ኮትስ~",
                "ፍቅር ሲይዘዉ ሁሉም ሰዉ ገጣሚ ይሆናል  \n" + "\n" + "~ፕላቶ~",
                "ምንም መጥፎ ነገር ባደርግ አንቺን ለመርሳት የምችልበትን ነገር እረሳለሁ\n" + "\n" + "~ሳድ ኮትስ~",
                "ብዙ ጊዜ በፍቅር ወድቄያለሁ…እሱም ካንቺ ጋር ብቻ !! \n" + "\n" + "~የማይታወቅ ሰዉ~",
                "እንደገና ከማፍቀር ዉጪ ለፍቅር ምንም መድሀኒት የለዉም! \n" + "\n" + "~ዴቪድ ሄንሪ~",
                "ማፍቀር ቀላል ሆኖ መፈቀር የሚከብደዉ ለምን ይሆን  \n" + "\n" + "~ፖ.ካንዲ~",
                "ከፈለክሽ ልትጠዪኝ ትችያለሽ…በኔ አለም ዉስጥ ከተሰረዝሽ ቆይተሻል \n" + "\n" + "~ትሩዝ ኮትስ~",
                "ፍቅር እነዚህን ቅመሞች ይዟል… እርስ በርሳቸዉ የሚተዋወቁ፣የሚጠባበቁና ሰላም የሚባባሉ ነፍሶች! \n\n ~ሬይነር ማሪያ~",
                "ፍቅር እንደንፋስ ነዉ፣አታየዉም ግን ስሜቱን ታዳምጠዋለህ   \n\n~ኒኮላስ ስፓርክስ~",
                "ብልህ ሆኖ ማፍቀር ትክክለኛዉ አማራጭ ነዉ፡፡ ነገር ግን ምንም ካለማፍቀር ሞኝ አፍቃሪ መሆን ይሻላል፡፡ \n\n~ሚልያም ሜክፒስ~",
                "ምክንያት የሌለዉ ፍቅር ረዥም ጊዜ ይቆያል  \n\n~ያልታወቀ ሰዉ~",
                "ፍቅር ቃለ-መሃላ ነዉ፡፡ ፍቅር ጌጥ ነዉ፤ አንዴ ከተሰጠ መቼም አይረሳም ስለዚህ ፍቅር እንዲጠፋ አትፍቀድ፡፡ \n\n~ጆን ሌኖን~",
                "ፍቅር ሁለት ሰዎች ተጫዉተዉ ሁለቱም የሚያሸንፉበት መድረክ  ነዉ፡፡ \n\n~ኤቫ ጌበር~")

    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen_slide)

        val statusBarSetting : Window = this.window
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){

            statusBarSetting.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            statusBarSetting.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            statusBarSetting.statusBarColor = ContextCompat.getColor(this,android.R.color.black)

        }


        mPager = findViewById(R.id.pager)
        myButton = findViewById(R.id.new_but)
        backgroundLayout = findViewById (R.id.backgroundImage)
        mAdView = findViewById(R.id.adView)

        mPagerAdapter = ScreenSlidePagerAdapter(supportFragmentManager)
        mPager.adapter = mPagerAdapter


        Glide.with(this).load(R.drawable.adv).into(backgroundLayout)

        val adRequest = AdRequest.Builder().build()

        mAdView.loadAd(adRequest)
        myButton.setOnClickListener {

            val prefs = getPreferences(Context.MODE_PRIVATE)
            var clickCount = prefs.getInt(ContentOne.KEY_CLICK_COUNT,0)
            clickCount ++

            val sharingIntent = Intent(Intent.ACTION_SEND)
            sharingIntent.type = "text/plain"
            sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "ፍቅር...")
            sharingIntent.putExtra(Intent.EXTRA_TEXT,quoteContents[mPager.currentItem])
            startActivity(Intent.createChooser(sharingIntent, "ሼር ያድርጉ!"))
            prefs.edit().putInt(ContentOne.KEY_CLICK_COUNT,clickCount).apply()


        }
    }

    inner class ScreenSlidePagerAdapter(fm: FragmentManager) : FragmentStatePagerAdapter(fm) {

        private val mCount = quoteContents.size

        override fun getItem(position: Int): Fragment {

            return  ViewPagerAdapter.newInstance(quoteContents[position % quoteContents.size])
        }
        override fun getCount(): Int = mCount

    }

}



