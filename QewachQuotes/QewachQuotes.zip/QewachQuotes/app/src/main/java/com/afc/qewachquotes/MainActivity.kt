package com.afc.qewachquotes
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.*
import android.widget.*


class MainActivity : AppCompatActivity() {
    internal val gridImages = arrayOf(
            R.drawable.s1, R.drawable.s2,
            R.drawable.s3, R.drawable.s4,
            R.drawable.s5, R.drawable.s6,
            R.drawable.s7, R.drawable.s8,
            R.drawable.s10, R.drawable.s9
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.content_main)

        val statusBarSetting : Window = this.window

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){

            statusBarSetting.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            statusBarSetting.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            statusBarSetting.statusBarColor = ContextCompat.getColor(this,android.R.color.black)

        }


        class ImageAdapter(private val mContext: Context?) : BaseAdapter() {

            override fun getCount(): Int = gridImages.size

            override fun getItem(position: Int): Any? = null

            override fun getItemId(position: Int): Long = 0

            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View? {

                val imageView = ImageView(mContext)
                val params = RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT)
                imageView.layoutParams = AbsListView.LayoutParams(params)
                imageView.scaleType = ImageView.ScaleType.CENTER_CROP
                imageView.setPadding(8, 8, 8, 8)
                imageView.setImageResource(gridImages[position])
                return imageView
            }

        }


        val gridView = findViewById<GridView>(R.id.gridview)
        gridView.adapter = ImageAdapter(this)
        gridView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
           var  intent = Intent()

            when (position) {
                0 -> {
                     intent = Intent(this@MainActivity,ContentOne :: class.java)
                }
                1 -> {
                     intent = Intent(this@MainActivity,ContentTwo :: class.java)
                }
                2 -> {
                     intent = Intent(this@MainActivity,ContentThree :: class.java)
                }
                3 -> {
                     intent = Intent(this@MainActivity,ContentFour :: class.java)
                }
                4 -> {
                     intent = Intent(this@MainActivity,ContentFive :: class.java)
                }
                5 -> {
                     intent = Intent(this@MainActivity,ContentSix :: class.java)
                }
                6 -> {
                     intent = Intent(this@MainActivity,ContentSeven :: class.java)
                }
                7 -> {
                     intent = Intent(this@MainActivity,ContentEight :: class.java)
                }
                8 -> {
                    intent = Intent(this@MainActivity,ContentNine :: class.java)
                }
                9 -> {
                     intent = Intent(this@MainActivity,ContentTen :: class.java)
                } else -> {

                Log.d("ERROR","Please Check the Code Haile!")
               }
             }
            startActivity(intent)
           }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        val id = item.itemId
        val url = "https://ethiocoderzone.wordpress.com/2018/10/11/%E1%88%9D%E1%88%AD%E1%8C%A5-%E1%8B%A8%E1%8A%A0%E1%88%88%E1%88%9D-%E1%8C%A5%E1%89%85%E1%88%B6%E1%89%BD-world-quotes-for-ethiopians/"

        if (id == R.id.action_privacy) {

            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                startActivity(intent)

            } catch(e : Throwable){
                print("Error in Connecting to the server.Please check at $e")
            }

            return true

        } else if (id == R.id.action_settings) {

            val intent = Intent(this@MainActivity, AboutUs::class.java)
            startActivity(intent)
        }
        return super.onOptionsItemSelected(item)
    }



}

