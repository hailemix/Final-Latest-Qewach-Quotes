package com.afc.qewachquotes
import android.graphics.Color
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Created by Haile on 11/29/2016.
 */

class ViewPagerAdapter : Fragment() {

    private var mContent = "???"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        if (savedInstanceState != null && savedInstanceState.containsKey(KEY_quoteContents)) {
            mContent = savedInstanceState.getString(KEY_quoteContents)
        }
    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val text = TextView(activity)
        text.gravity = Gravity.CENTER
        text.text = mContent
        text.textSize = 30f
        text.setPadding(20, 20, 20, 20)
        text.setTextColor(Color.WHITE)

        val layout = LinearLayout(activity)
        layout.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT)
        layout.gravity = Gravity.CENTER
        layout.addView(text)

        return layout
    }


    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(KEY_quoteContents, mContent)
    }

    companion object {


        private const val KEY_quoteContents = "TestFragment:Content"

        fun newInstance(content: String): ViewPagerAdapter {
            val fragment = ViewPagerAdapter()

            val builder = StringBuilder()
            for (i in 0..0) {
                builder.append(content).append(" ")
            }
            builder.deleteCharAt(builder.length - 1)
            fragment.mContent = builder.toString()

            return fragment
        }
    }
}
